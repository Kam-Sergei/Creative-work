/********************************************************************************
** Form generated from reading UI file 'calculator.ui'
**
** Created by: Qt User Interface Compiler version 5.12.10
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_CALCULATOR_H
#define UI_CALCULATOR_H

#include <QtCore/QVariant>
#include <QtGui/QIcon>
#include <QtWidgets/QApplication>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_calculator
{
public:
    QWidget *centralwidget;
    QPushButton *b7;
    QPushButton *bDegree;
    QPushButton *bl;
    QPushButton *b9;
    QPushButton *bDot;
    QLabel *tablo_error;
    QPushButton *b3;
    QPushButton *bMultiply;
    QLineEdit *tablo_3;
    QPushButton *b4;
    QPushButton *b0;
    QPushButton *btransion;
    QPushButton *bLog;
    QPushButton *bRoot;
    QPushButton *bResult;
    QPushButton *bDivision;
    QPushButton *b1;
    QLineEdit *tablo_1;
    QPushButton *bMinus;
    QLabel *tablo_2;
    QPushButton *bdivision;
    QPushButton *bSign;
    QPushButton *b2;
    QPushButton *b8;
    QPushButton *br;
    QPushButton *bDEL;
    QPushButton *b5;
    QPushButton *bPlus;
    QPushButton *b6;
    QPushButton *bClear;
    QPushButton *blanguage;
    QPushButton *b00;

    void setupUi(QMainWindow *calculator)
    {
        if (calculator->objectName().isEmpty())
            calculator->setObjectName(QString::fromUtf8("calculator"));
        calculator->resize(590, 619);
        calculator->setMinimumSize(QSize(590, 619));
        calculator->setMaximumSize(QSize(590, 619));
        QIcon icon;
        icon.addFile(QString::fromUtf8(":/button_images/images/Icon.png"), QSize(), QIcon::Normal, QIcon::Off);
        calculator->setWindowIcon(icon);
        calculator->setStyleSheet(QString::fromUtf8("QMainWindow\n"
"{\n"
"background:qlineargradient(spread:pad, x1:0.51, y1:0, x2:0.519, y2:1, stop:0 rgba(25, 217, 255, 255), stop:0.509615 rgba(123, 237, 255, 255), stop:1 rgba(35, 167, 255, 255));\n"
"}\n"
""));
        centralwidget = new QWidget(calculator);
        centralwidget->setObjectName(QString::fromUtf8("centralwidget"));
        b7 = new QPushButton(centralwidget);
        b7->setObjectName(QString::fromUtf8("b7"));
        b7->setGeometry(QRect(90, 300, 60, 60));
        QSizePolicy sizePolicy(QSizePolicy::Fixed, QSizePolicy::Fixed);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(b7->sizePolicy().hasHeightForWidth());
        b7->setSizePolicy(sizePolicy);
        QFont font;
        font.setFamily(QString::fromUtf8("Times New Roman"));
        font.setPointSize(20);
        font.setBold(true);
        font.setUnderline(false);
        font.setWeight(75);
        font.setStrikeOut(false);
        b7->setFont(font);
        b7->setStyleSheet(QString::fromUtf8("QPushButton\n"
"{\n"
"text-decoration: none;\n"
"padding 0 0 0 0;\n"
"ouline:none;\n"
"border-width:2px;\n"
"border-style:solid;\n"
"border-color:rgb(0, 85, 0);\n"
"border-radius:15px;\n"
"background: qlineargradient(spread:pad, x1:0.504808, y1:0, x2:0.51, y2:0.988636, stop:0.00480769 rgba(62, 255, 62, 255), stop:0.25 rgba(188, 255, 194, 255), stop:1 rgba(0, 156, 112, 255));\n"
"}\n"
":hover{background: qlineargradient(spread:pad, x1:0.504808, y1:0, x2:0.51, y2:0.988636, stop:0.00480769 rgba(62, 255, 62, 255), stop:0.504808 rgba(188, 255, 194, 255), stop:1 rgba(0, 156, 112, 255));}\n"
":pressed{background: qlineargradient(spread:pad, x1:0.504808, y1:0, x2:0.51, y2:0.988636, stop:0.00480769 rgba(62, 255, 62, 255), stop:0.783654 rgba(188, 255, 194, 255), stop:1 rgba(0, 156, 112, 255));}"));
        b7->setIconSize(QSize(20, 20));
        bDegree = new QPushButton(centralwidget);
        bDegree->setObjectName(QString::fromUtf8("bDegree"));
        bDegree->setGeometry(QRect(300, 300, 60, 60));
        sizePolicy.setHeightForWidth(bDegree->sizePolicy().hasHeightForWidth());
        bDegree->setSizePolicy(sizePolicy);
        bDegree->setFont(font);
        bDegree->setStyleSheet(QString::fromUtf8("QPushButton\n"
"{\n"
"text-decoration: none;\n"
"padding 0 0 0 0;\n"
"ouline:none;\n"
"border-width:2px;\n"
"border-style:solid;\n"
"border-color:rgb(4, 0, 125);\n"
"border-radius:15px;\n"
"background:qlineargradient(spread:pad, x1:0.50805, y1:0, x2:0.498, y2:1, stop:0 rgba(0, 13, 255, 255), stop:0.238806 rgba(125, 188, 255, 255), stop:1 rgba(0, 0, 145, 255));\n"
"}\n"
":hover{background:qlineargradient(spread:pad, x1:0.50805, y1:0, x2:0.498, y2:1, stop:0 rgba(0, 13, 255, 255), stop:0.492537 rgba(125, 188, 255, 255), stop:1 rgba(0, 0, 145, 255));}\n"
":pressed{background: qlineargradient(spread:pad, x1:0.50805, y1:0, x2:0.498, y2:1, stop:0 rgba(0, 13, 255, 255), stop:0.791045 rgba(125, 188, 255, 255), stop:1 rgba(0, 0, 145, 255));}"));
        QIcon icon1;
        icon1.addFile(QString::fromUtf8(":/button_images/images/degree.png"), QSize(), QIcon::Normal, QIcon::Off);
        bDegree->setIcon(icon1);
        bDegree->setIconSize(QSize(50, 50));
        bl = new QPushButton(centralwidget);
        bl->setObjectName(QString::fromUtf8("bl"));
        bl->setGeometry(QRect(440, 300, 60, 60));
        sizePolicy.setHeightForWidth(bl->sizePolicy().hasHeightForWidth());
        bl->setSizePolicy(sizePolicy);
        bl->setFont(font);
        bl->setStyleSheet(QString::fromUtf8("QPushButton\n"
"{\n"
"text-decoration: none;\n"
"padding 0 0 0 0;\n"
"ouline:none;\n"
"border-width:2px;\n"
"border-style:solid;\n"
"border-color:rgb(230, 139, 48);\n"
"border-radius:15px;\n"
"background:qlineargradient(spread:pad, x1:0.50805, y1:0, x2:0.498, y2:1, stop:0 rgba(255, 169, 70, 255), stop:0.238806 rgba(255, 216, 152, 255), stop:1 rgba(255, 157, 59, 255));\n"
"}\n"
":hover{background:qlineargradient(spread:pad, x1:0.50805, y1:0, x2:0.498, y2:1, stop:0 rgba(255, 167, 66, 255), stop:0.492537 rgba(255, 216, 152, 255), stop:1 rgba(255, 173, 90, 255));}\n"
":pressed{background: qlineargradient(spread:pad, x1:0.50805, y1:0, x2:0.498, y2:1, stop:0 rgba(255, 162, 56, 255), stop:0.800995 rgba(255, 216, 152, 255), stop:1 rgba(255, 173, 90, 255));}"));
        b9 = new QPushButton(centralwidget);
        b9->setObjectName(QString::fromUtf8("b9"));
        b9->setGeometry(QRect(230, 300, 60, 60));
        sizePolicy.setHeightForWidth(b9->sizePolicy().hasHeightForWidth());
        b9->setSizePolicy(sizePolicy);
        b9->setFont(font);
        b9->setStyleSheet(QString::fromUtf8("QPushButton\n"
"{\n"
"text-decoration: none;\n"
"padding 0 0 0 0;\n"
"ouline:none;\n"
"border-width:2px;\n"
"border-style:solid;\n"
"border-color:rgb(0, 85, 0);\n"
"border-radius:15px;\n"
"background: qlineargradient(spread:pad, x1:0.504808, y1:0, x2:0.51, y2:0.988636, stop:0.00480769 rgba(62, 255, 62, 255), stop:0.25 rgba(188, 255, 194, 255), stop:1 rgba(0, 156, 112, 255));\n"
"}\n"
":hover{background: qlineargradient(spread:pad, x1:0.504808, y1:0, x2:0.51, y2:0.988636, stop:0.00480769 rgba(62, 255, 62, 255), stop:0.504808 rgba(188, 255, 194, 255), stop:1 rgba(0, 156, 112, 255));}\n"
":pressed{background: qlineargradient(spread:pad, x1:0.504808, y1:0, x2:0.51, y2:0.988636, stop:0.00480769 rgba(62, 255, 62, 255), stop:0.783654 rgba(188, 255, 194, 255), stop:1 rgba(0, 156, 112, 255));}"));
        bDot = new QPushButton(centralwidget);
        bDot->setObjectName(QString::fromUtf8("bDot"));
        bDot->setGeometry(QRect(230, 510, 60, 60));
        sizePolicy.setHeightForWidth(bDot->sizePolicy().hasHeightForWidth());
        bDot->setSizePolicy(sizePolicy);
        bDot->setFont(font);
        bDot->setStyleSheet(QString::fromUtf8("QPushButton\n"
"{\n"
"text-decoration: none;\n"
"padding 0 0 0 0;\n"
"ouline:none;\n"
"border-width:2px;\n"
"border-style:solid;\n"
"border-color:rgb(0, 85, 0);\n"
"border-radius:15px;\n"
"background: qlineargradient(spread:pad, x1:0.504808, y1:0, x2:0.51, y2:0.988636, stop:0.00480769 rgba(62, 255, 62, 255), stop:0.25 rgba(188, 255, 194, 255), stop:1 rgba(0, 156, 112, 255));\n"
"}\n"
":hover{background: qlineargradient(spread:pad, x1:0.504808, y1:0, x2:0.51, y2:0.988636, stop:0.00480769 rgba(62, 255, 62, 255), stop:0.504808 rgba(188, 255, 194, 255), stop:1 rgba(0, 156, 112, 255));}\n"
":pressed{background: qlineargradient(spread:pad, x1:0.504808, y1:0, x2:0.51, y2:0.988636, stop:0.00480769 rgba(62, 255, 62, 255), stop:0.783654 rgba(188, 255, 194, 255), stop:1 rgba(0, 156, 112, 255));}"));
        tablo_error = new QLabel(centralwidget);
        tablo_error->setObjectName(QString::fromUtf8("tablo_error"));
        tablo_error->setGeometry(QRect(50, 10, 491, 51));
        QFont font1;
        font1.setFamily(QString::fromUtf8("Times New Roman"));
        font1.setPointSize(10);
        font1.setBold(true);
        font1.setUnderline(true);
        font1.setWeight(75);
        tablo_error->setFont(font1);
        tablo_error->setAlignment(Qt::AlignCenter);
        b3 = new QPushButton(centralwidget);
        b3->setObjectName(QString::fromUtf8("b3"));
        b3->setGeometry(QRect(230, 440, 60, 60));
        sizePolicy.setHeightForWidth(b3->sizePolicy().hasHeightForWidth());
        b3->setSizePolicy(sizePolicy);
        b3->setFont(font);
        b3->setStyleSheet(QString::fromUtf8("QPushButton\n"
"{\n"
"text-decoration: none;\n"
"padding 0 0 0 0;\n"
"ouline:none;\n"
"border-width:2px;\n"
"border-style:solid;\n"
"border-color:rgb(0, 85, 0);\n"
"border-radius:15px;\n"
"background: qlineargradient(spread:pad, x1:0.504808, y1:0, x2:0.51, y2:0.988636, stop:0.00480769 rgba(62, 255, 62, 255), stop:0.25 rgba(188, 255, 194, 255), stop:1 rgba(0, 156, 112, 255));\n"
"}\n"
":hover{background: qlineargradient(spread:pad, x1:0.504808, y1:0, x2:0.51, y2:0.988636, stop:0.00480769 rgba(62, 255, 62, 255), stop:0.504808 rgba(188, 255, 194, 255), stop:1 rgba(0, 156, 112, 255));}\n"
":pressed{background: qlineargradient(spread:pad, x1:0.504808, y1:0, x2:0.51, y2:0.988636, stop:0.00480769 rgba(62, 255, 62, 255), stop:0.783654 rgba(188, 255, 194, 255), stop:1 rgba(0, 156, 112, 255));}"));
        bMultiply = new QPushButton(centralwidget);
        bMultiply->setObjectName(QString::fromUtf8("bMultiply"));
        bMultiply->setGeometry(QRect(300, 370, 60, 60));
        sizePolicy.setHeightForWidth(bMultiply->sizePolicy().hasHeightForWidth());
        bMultiply->setSizePolicy(sizePolicy);
        bMultiply->setFont(font);
        bMultiply->setStyleSheet(QString::fromUtf8("QPushButton\n"
"{\n"
"text-decoration: none;\n"
"padding 0 0 0 0;\n"
"ouline:none;\n"
"border-width:2px;\n"
"border-style:solid;\n"
"border-color:rgb(4, 0, 125);\n"
"border-radius:15px;\n"
"background:qlineargradient(spread:pad, x1:0.50805, y1:0, x2:0.498, y2:1, stop:0 rgba(0, 13, 255, 255), stop:0.238806 rgba(125, 188, 255, 255), stop:1 rgba(0, 0, 145, 255));\n"
"}\n"
":hover{background:qlineargradient(spread:pad, x1:0.50805, y1:0, x2:0.498, y2:1, stop:0 rgba(0, 13, 255, 255), stop:0.492537 rgba(125, 188, 255, 255), stop:1 rgba(0, 0, 145, 255));}\n"
":pressed{background: qlineargradient(spread:pad, x1:0.50805, y1:0, x2:0.498, y2:1, stop:0 rgba(0, 13, 255, 255), stop:0.791045 rgba(125, 188, 255, 255), stop:1 rgba(0, 0, 145, 255));}"));
        tablo_3 = new QLineEdit(centralwidget);
        tablo_3->setObjectName(QString::fromUtf8("tablo_3"));
        tablo_3->setGeometry(QRect(90, 170, 411, 51));
        tablo_3->setFont(font);
        tablo_3->setLayoutDirection(Qt::LeftToRight);
        tablo_3->setStyleSheet(QString::fromUtf8("QLineEdit\n"
"{\n"
"text-decoration: none;\n"
"padding 0 0 0 0;\n"
"ouline:none;\n"
"border-width:2px;\n"
"border-style:solid;\n"
"border-color:rgb(234, 234, 234);\n"
"border-radius:5px;\n"
"background:qlineargradient(spread:pad, x1:0.50805, y1:0, x2:0.498, y2:1, stop:0 rgba(229, 229, 229, 255), stop:0.452736 rgba(252, 252, 252, 255), stop:1 rgba(212, 212, 212, 255));\n"
"}"));
        tablo_3->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);
        b4 = new QPushButton(centralwidget);
        b4->setObjectName(QString::fromUtf8("b4"));
        b4->setGeometry(QRect(90, 370, 60, 60));
        sizePolicy.setHeightForWidth(b4->sizePolicy().hasHeightForWidth());
        b4->setSizePolicy(sizePolicy);
        b4->setFont(font);
        b4->setStyleSheet(QString::fromUtf8("QPushButton\n"
"{\n"
"text-decoration: none;\n"
"padding 0 0 0 0;\n"
"ouline:none;\n"
"border-width:2px;\n"
"border-style:solid;\n"
"border-color:rgb(0, 85, 0);\n"
"border-radius:15px;\n"
"background: qlineargradient(spread:pad, x1:0.504808, y1:0, x2:0.51, y2:0.988636, stop:0.00480769 rgba(62, 255, 62, 255), stop:0.25 rgba(188, 255, 194, 255), stop:1 rgba(0, 156, 112, 255));\n"
"}\n"
":hover{background: qlineargradient(spread:pad, x1:0.504808, y1:0, x2:0.51, y2:0.988636, stop:0.00480769 rgba(62, 255, 62, 255), stop:0.504808 rgba(188, 255, 194, 255), stop:1 rgba(0, 156, 112, 255));}\n"
":pressed{background: qlineargradient(spread:pad, x1:0.504808, y1:0, x2:0.51, y2:0.988636, stop:0.00480769 rgba(62, 255, 62, 255), stop:0.783654 rgba(188, 255, 194, 255), stop:1 rgba(0, 156, 112, 255));}"));
        b0 = new QPushButton(centralwidget);
        b0->setObjectName(QString::fromUtf8("b0"));
        b0->setGeometry(QRect(90, 510, 60, 60));
        sizePolicy.setHeightForWidth(b0->sizePolicy().hasHeightForWidth());
        b0->setSizePolicy(sizePolicy);
        b0->setFont(font);
        b0->setStyleSheet(QString::fromUtf8("QPushButton\n"
"{\n"
"text-decoration: none;\n"
"padding 0 0 0 0;\n"
"ouline:none;\n"
"border-width:2px;\n"
"border-style:solid;\n"
"border-color:rgb(0, 85, 0);\n"
"border-radius:15px;\n"
"background: qlineargradient(spread:pad, x1:0.504808, y1:0, x2:0.51, y2:0.988636, stop:0.00480769 rgba(62, 255, 62, 255), stop:0.25 rgba(188, 255, 194, 255), stop:1 rgba(0, 156, 112, 255));\n"
"}\n"
":hover{background: qlineargradient(spread:pad, x1:0.504808, y1:0, x2:0.51, y2:0.988636, stop:0.00480769 rgba(62, 255, 62, 255), stop:0.504808 rgba(188, 255, 194, 255), stop:1 rgba(0, 156, 112, 255));}\n"
":pressed{background: qlineargradient(spread:pad, x1:0.504808, y1:0, x2:0.51, y2:0.988636, stop:0.00480769 rgba(62, 255, 62, 255), stop:0.783654 rgba(188, 255, 194, 255), stop:1 rgba(0, 156, 112, 255));}"));
        btransion = new QPushButton(centralwidget);
        btransion->setObjectName(QString::fromUtf8("btransion"));
        btransion->setGeometry(QRect(440, 230, 60, 60));
        sizePolicy.setHeightForWidth(btransion->sizePolicy().hasHeightForWidth());
        btransion->setSizePolicy(sizePolicy);
        btransion->setFont(font);
        btransion->setStyleSheet(QString::fromUtf8("QPushButton\n"
"{\n"
"text-decoration: none;\n"
"padding 0 0 0 0;\n"
"ouline:none;\n"
"border-width:2px;\n"
"border-style:solid;\n"
"border-color:rgb(230, 139, 48);\n"
"border-radius:15px;\n"
"background:qlineargradient(spread:pad, x1:0.50805, y1:0, x2:0.498, y2:1, stop:0 rgba(255, 169, 70, 255), stop:0.238806 rgba(255, 216, 152, 255), stop:1 rgba(255, 157, 59, 255));\n"
"}\n"
":hover{background:qlineargradient(spread:pad, x1:0.50805, y1:0, x2:0.498, y2:1, stop:0 rgba(255, 167, 66, 255), stop:0.492537 rgba(255, 216, 152, 255), stop:1 rgba(255, 173, 90, 255));}\n"
":pressed{background: qlineargradient(spread:pad, x1:0.50805, y1:0, x2:0.498, y2:1, stop:0 rgba(255, 162, 56, 255), stop:0.800995 rgba(255, 216, 152, 255), stop:1 rgba(255, 173, 90, 255));}"));
        QIcon icon2;
        icon2.addFile(QString::fromUtf8(":/button_images/images/transition.png"), QSize(), QIcon::Normal, QIcon::Off);
        btransion->setIcon(icon2);
        btransion->setIconSize(QSize(50, 50));
        bLog = new QPushButton(centralwidget);
        bLog->setObjectName(QString::fromUtf8("bLog"));
        bLog->setGeometry(QRect(230, 230, 201, 60));
        sizePolicy.setHeightForWidth(bLog->sizePolicy().hasHeightForWidth());
        bLog->setSizePolicy(sizePolicy);
        bLog->setFont(font);
        bLog->setStyleSheet(QString::fromUtf8("QPushButton\n"
"{\n"
"text-decoration: none;\n"
"padding 0 0 0 0;\n"
"ouline:none;\n"
"border-width:2px;\n"
"border-style:solid;\n"
"border-color:rgb(230, 139, 48);\n"
"border-radius:15px;\n"
"background:qlineargradient(spread:pad, x1:0.50805, y1:0, x2:0.498, y2:1, stop:0 rgba(255, 169, 70, 255), stop:0.238806 rgba(255, 216, 152, 255), stop:1 rgba(255, 157, 59, 255));\n"
"}\n"
":hover{background:qlineargradient(spread:pad, x1:0.50805, y1:0, x2:0.498, y2:1, stop:0 rgba(255, 167, 66, 255), stop:0.492537 rgba(255, 216, 152, 255), stop:1 rgba(255, 173, 90, 255));}\n"
":pressed{background: qlineargradient(spread:pad, x1:0.50805, y1:0, x2:0.498, y2:1, stop:0 rgba(255, 162, 56, 255), stop:0.800995 rgba(255, 216, 152, 255), stop:1 rgba(255, 173, 90, 255));}"));
        QIcon icon3;
        icon3.addFile(QString::fromUtf8(":/button_images/images/logarithm.png"), QSize(), QIcon::Normal, QIcon::Off);
        bLog->setIcon(icon3);
        bLog->setIconSize(QSize(250, 70));
        bRoot = new QPushButton(centralwidget);
        bRoot->setObjectName(QString::fromUtf8("bRoot"));
        bRoot->setGeometry(QRect(370, 300, 60, 60));
        sizePolicy.setHeightForWidth(bRoot->sizePolicy().hasHeightForWidth());
        bRoot->setSizePolicy(sizePolicy);
        bRoot->setFont(font);
        bRoot->setStyleSheet(QString::fromUtf8("QPushButton\n"
"{\n"
"text-decoration: none;\n"
"padding 0 0 0 0;\n"
"ouline:none;\n"
"border-width:2px;\n"
"border-style:solid;\n"
"border-color:rgb(4, 0, 125);\n"
"border-radius:15px;\n"
"background:qlineargradient(spread:pad, x1:0.50805, y1:0, x2:0.498, y2:1, stop:0 rgba(0, 13, 255, 255), stop:0.238806 rgba(125, 188, 255, 255), stop:1 rgba(0, 0, 145, 255));\n"
"}\n"
":hover{background:qlineargradient(spread:pad, x1:0.50805, y1:0, x2:0.498, y2:1, stop:0 rgba(0, 13, 255, 255), stop:0.492537 rgba(125, 188, 255, 255), stop:1 rgba(0, 0, 145, 255));}\n"
":pressed{background: qlineargradient(spread:pad, x1:0.50805, y1:0, x2:0.498, y2:1, stop:0 rgba(0, 13, 255, 255), stop:0.791045 rgba(125, 188, 255, 255), stop:1 rgba(0, 0, 145, 255));}"));
        QIcon icon4;
        icon4.addFile(QString::fromUtf8(":/button_images/images/root.png"), QSize(), QIcon::Normal, QIcon::Off);
        bRoot->setIcon(icon4);
        bRoot->setIconSize(QSize(50, 50));
        bResult = new QPushButton(centralwidget);
        bResult->setObjectName(QString::fromUtf8("bResult"));
        bResult->setGeometry(QRect(440, 439, 61, 131));
        QSizePolicy sizePolicy1(QSizePolicy::Fixed, QSizePolicy::Fixed);
        sizePolicy1.setHorizontalStretch(78);
        sizePolicy1.setVerticalStretch(80);
        sizePolicy1.setHeightForWidth(bResult->sizePolicy().hasHeightForWidth());
        bResult->setSizePolicy(sizePolicy1);
        bResult->setFont(font);
        bResult->setStyleSheet(QString::fromUtf8("QPushButton\n"
"{\n"
"text-decoration: none;\n"
"padding 0 0 0 0;\n"
"ouline:none;\n"
"border-width:2px;\n"
"border-style:solid;\n"
"border-color:rgb(199, 66, 0);\n"
"border-radius:15px;\n"
"background:qlineargradient(spread:pad, x1:0.504808, y1:0, x2:0.51, y2:0.988636, stop:0.00480769 rgba(255, 133, 46, 255), stop:0.25 rgba(255, 193, 152, 255), stop:1 rgba(244, 102, 32, 255));\n"
"}\n"
":hover{background: qlineargradient(spread:pad, x1:0.504808, y1:0, x2:0.51, y2:0.988636, stop:0.00480769 rgba(255, 133, 46, 255), stop:0.509615 rgba(255, 193, 152, 255), stop:1 rgba(244, 102, 32, 255));}\n"
":pressed{background: qlineargradient(spread:pad, x1:0.504808, y1:0, x2:0.51, y2:0.988636, stop:0.00480769 rgba(255, 133, 46, 255), stop:0.793269 rgba(255, 193, 152, 255), stop:1 rgba(244, 102, 32, 255));}"));
        bResult->setIconSize(QSize(40, 40));
        bDivision = new QPushButton(centralwidget);
        bDivision->setObjectName(QString::fromUtf8("bDivision"));
        bDivision->setGeometry(QRect(370, 370, 60, 60));
        sizePolicy.setHeightForWidth(bDivision->sizePolicy().hasHeightForWidth());
        bDivision->setSizePolicy(sizePolicy);
        bDivision->setFont(font);
        bDivision->setStyleSheet(QString::fromUtf8("QPushButton\n"
"{\n"
"text-decoration: none;\n"
"padding 0 0 0 0;\n"
"ouline:none;\n"
"border-width:2px;\n"
"border-style:solid;\n"
"border-color:rgb(4, 0, 125);\n"
"border-radius:15px;\n"
"background:qlineargradient(spread:pad, x1:0.50805, y1:0, x2:0.498, y2:1, stop:0 rgba(0, 13, 255, 255), stop:0.238806 rgba(125, 188, 255, 255), stop:1 rgba(0, 0, 145, 255));\n"
"}\n"
":hover{background:qlineargradient(spread:pad, x1:0.50805, y1:0, x2:0.498, y2:1, stop:0 rgba(0, 13, 255, 255), stop:0.492537 rgba(125, 188, 255, 255), stop:1 rgba(0, 0, 145, 255));}\n"
":pressed{background: qlineargradient(spread:pad, x1:0.50805, y1:0, x2:0.498, y2:1, stop:0 rgba(0, 13, 255, 255), stop:0.791045 rgba(125, 188, 255, 255), stop:1 rgba(0, 0, 145, 255));}"));
        b1 = new QPushButton(centralwidget);
        b1->setObjectName(QString::fromUtf8("b1"));
        b1->setGeometry(QRect(90, 440, 60, 60));
        sizePolicy.setHeightForWidth(b1->sizePolicy().hasHeightForWidth());
        b1->setSizePolicy(sizePolicy);
        b1->setFont(font);
        b1->setStyleSheet(QString::fromUtf8("QPushButton\n"
"{\n"
"text-decoration: none;\n"
"padding 0 0 0 0;\n"
"ouline:none;\n"
"border-width:2px;\n"
"border-style:solid;\n"
"border-color:rgb(0, 85, 0);\n"
"border-radius:15px;\n"
"background: qlineargradient(spread:pad, x1:0.504808, y1:0, x2:0.51, y2:0.988636, stop:0.00480769 rgba(62, 255, 62, 255), stop:0.25 rgba(188, 255, 194, 255), stop:1 rgba(0, 156, 112, 255));\n"
"}\n"
":hover{background: qlineargradient(spread:pad, x1:0.504808, y1:0, x2:0.51, y2:0.988636, stop:0.00480769 rgba(62, 255, 62, 255), stop:0.504808 rgba(188, 255, 194, 255), stop:1 rgba(0, 156, 112, 255));}\n"
":pressed{background: qlineargradient(spread:pad, x1:0.504808, y1:0, x2:0.51, y2:0.988636, stop:0.00480769 rgba(62, 255, 62, 255), stop:0.783654 rgba(188, 255, 194, 255), stop:1 rgba(0, 156, 112, 255));}"));
        tablo_1 = new QLineEdit(centralwidget);
        tablo_1->setObjectName(QString::fromUtf8("tablo_1"));
        tablo_1->setGeometry(QRect(90, 70, 411, 51));
        tablo_1->setFont(font);
        tablo_1->setLayoutDirection(Qt::LeftToRight);
        tablo_1->setStyleSheet(QString::fromUtf8("QLineEdit\n"
"{\n"
"text-decoration: none;\n"
"padding 0 0 0 0;\n"
"ouline:none;\n"
"border-width:2px;\n"
"border-style:solid;\n"
"border-color:rgb(234, 234, 234);\n"
"border-radius:5px;\n"
"background:qlineargradient(spread:pad, x1:0.50805, y1:0, x2:0.498, y2:1, stop:0 rgba(229, 229, 229, 255), stop:0.452736 rgba(252, 252, 252, 255), stop:1 rgba(212, 212, 212, 255));\n"
"}\n"
""));
        tablo_1->setMaxLength(32767);
        tablo_1->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);
        bMinus = new QPushButton(centralwidget);
        bMinus->setObjectName(QString::fromUtf8("bMinus"));
        bMinus->setGeometry(QRect(370, 440, 60, 60));
        QSizePolicy sizePolicy2(QSizePolicy::Fixed, QSizePolicy::Fixed);
        sizePolicy2.setHorizontalStretch(80);
        sizePolicy2.setVerticalStretch(80);
        sizePolicy2.setHeightForWidth(bMinus->sizePolicy().hasHeightForWidth());
        bMinus->setSizePolicy(sizePolicy2);
        bMinus->setFont(font);
        bMinus->setStyleSheet(QString::fromUtf8("QPushButton\n"
"{\n"
"text-decoration: none;\n"
"padding 0 0 0 0;\n"
"ouline:none;\n"
"border-width:2px;\n"
"border-style:solid;\n"
"border-color:rgb(4, 0, 125);\n"
"border-radius:15px;\n"
"background:qlineargradient(spread:pad, x1:0.50805, y1:0, x2:0.498, y2:1, stop:0 rgba(0, 13, 255, 255), stop:0.238806 rgba(125, 188, 255, 255), stop:1 rgba(0, 0, 145, 255));\n"
"}\n"
":hover{background:qlineargradient(spread:pad, x1:0.50805, y1:0, x2:0.498, y2:1, stop:0 rgba(0, 13, 255, 255), stop:0.492537 rgba(125, 188, 255, 255), stop:1 rgba(0, 0, 145, 255));}\n"
":pressed{background: qlineargradient(spread:pad, x1:0.50805, y1:0, x2:0.498, y2:1, stop:0 rgba(0, 13, 255, 255), stop:0.791045 rgba(125, 188, 255, 255), stop:1 rgba(0, 0, 145, 255));}"));
        tablo_2 = new QLabel(centralwidget);
        tablo_2->setObjectName(QString::fromUtf8("tablo_2"));
        tablo_2->setGeometry(QRect(440, 120, 61, 49));
        QFont font2;
        font2.setFamily(QString::fromUtf8("Times New Roman"));
        font2.setPointSize(20);
        font2.setBold(true);
        font2.setWeight(75);
        tablo_2->setFont(font2);
        tablo_2->setLayoutDirection(Qt::LeftToRight);
        tablo_2->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);
        bdivision = new QPushButton(centralwidget);
        bdivision->setObjectName(QString::fromUtf8("bdivision"));
        bdivision->setGeometry(QRect(370, 510, 60, 60));
        sizePolicy.setHeightForWidth(bdivision->sizePolicy().hasHeightForWidth());
        bdivision->setSizePolicy(sizePolicy);
        bdivision->setFont(font);
        bdivision->setStyleSheet(QString::fromUtf8("QPushButton\n"
"{\n"
"text-decoration: none;\n"
"padding 0 0 0 0;\n"
"ouline:none;\n"
"border-width:2px;\n"
"border-style:solid;\n"
"border-color:rgb(4, 0, 125);\n"
"border-radius:15px;\n"
"background:qlineargradient(spread:pad, x1:0.50805, y1:0, x2:0.498, y2:1, stop:0 rgba(0, 13, 255, 255), stop:0.238806 rgba(125, 188, 255, 255), stop:1 rgba(0, 0, 145, 255));\n"
"}\n"
":hover{background:qlineargradient(spread:pad, x1:0.50805, y1:0, x2:0.498, y2:1, stop:0 rgba(0, 13, 255, 255), stop:0.492537 rgba(125, 188, 255, 255), stop:1 rgba(0, 0, 145, 255));}\n"
":pressed{background: qlineargradient(spread:pad, x1:0.50805, y1:0, x2:0.498, y2:1, stop:0 rgba(0, 13, 255, 255), stop:0.791045 rgba(125, 188, 255, 255), stop:1 rgba(0, 0, 145, 255));}"));
        QIcon icon5;
        icon5.addFile(QString::fromUtf8(":/button_images/images/division.png"), QSize(), QIcon::Normal, QIcon::Off);
        bdivision->setIcon(icon5);
        bdivision->setIconSize(QSize(50, 50));
        bSign = new QPushButton(centralwidget);
        bSign->setObjectName(QString::fromUtf8("bSign"));
        bSign->setGeometry(QRect(300, 510, 60, 60));
        sizePolicy.setHeightForWidth(bSign->sizePolicy().hasHeightForWidth());
        bSign->setSizePolicy(sizePolicy);
        bSign->setFont(font);
        bSign->setStyleSheet(QString::fromUtf8("QPushButton\n"
"{\n"
"text-decoration: none;\n"
"padding 0 0 0 0;\n"
"ouline:none;\n"
"border-width:2px;\n"
"border-style:solid;\n"
"border-color:rgb(4, 0, 125);\n"
"border-radius:15px;\n"
"background:qlineargradient(spread:pad, x1:0.50805, y1:0, x2:0.498, y2:1, stop:0 rgba(0, 13, 255, 255), stop:0.238806 rgba(125, 188, 255, 255), stop:1 rgba(0, 0, 145, 255));\n"
"}\n"
":hover{background:qlineargradient(spread:pad, x1:0.50805, y1:0, x2:0.498, y2:1, stop:0 rgba(0, 13, 255, 255), stop:0.492537 rgba(125, 188, 255, 255), stop:1 rgba(0, 0, 145, 255));}\n"
":pressed{background: qlineargradient(spread:pad, x1:0.50805, y1:0, x2:0.498, y2:1, stop:0 rgba(0, 13, 255, 255), stop:0.791045 rgba(125, 188, 255, 255), stop:1 rgba(0, 0, 145, 255));}"));
        bSign->setIconSize(QSize(20, 20));
        b2 = new QPushButton(centralwidget);
        b2->setObjectName(QString::fromUtf8("b2"));
        b2->setGeometry(QRect(160, 440, 60, 60));
        sizePolicy.setHeightForWidth(b2->sizePolicy().hasHeightForWidth());
        b2->setSizePolicy(sizePolicy);
        b2->setFont(font);
        b2->setStyleSheet(QString::fromUtf8("QPushButton\n"
"{\n"
"text-decoration: none;\n"
"padding 0 0 0 0;\n"
"ouline:none;\n"
"border-width:2px;\n"
"border-style:solid;\n"
"border-color:rgb(0, 85, 0);\n"
"border-radius:15px;\n"
"background: qlineargradient(spread:pad, x1:0.504808, y1:0, x2:0.51, y2:0.988636, stop:0.00480769 rgba(62, 255, 62, 255), stop:0.25 rgba(188, 255, 194, 255), stop:1 rgba(0, 156, 112, 255));\n"
"}\n"
":hover{background: qlineargradient(spread:pad, x1:0.504808, y1:0, x2:0.51, y2:0.988636, stop:0.00480769 rgba(62, 255, 62, 255), stop:0.504808 rgba(188, 255, 194, 255), stop:1 rgba(0, 156, 112, 255));}\n"
":pressed{background: qlineargradient(spread:pad, x1:0.504808, y1:0, x2:0.51, y2:0.988636, stop:0.00480769 rgba(62, 255, 62, 255), stop:0.783654 rgba(188, 255, 194, 255), stop:1 rgba(0, 156, 112, 255));}"));
        b2->setIconSize(QSize(20, 20));
        b8 = new QPushButton(centralwidget);
        b8->setObjectName(QString::fromUtf8("b8"));
        b8->setGeometry(QRect(160, 300, 60, 60));
        sizePolicy.setHeightForWidth(b8->sizePolicy().hasHeightForWidth());
        b8->setSizePolicy(sizePolicy);
        b8->setFont(font);
        b8->setStyleSheet(QString::fromUtf8("QPushButton\n"
"{\n"
"text-decoration: none;\n"
"padding 0 0 0 0;\n"
"ouline:none;\n"
"border-width:2px;\n"
"border-style:solid;\n"
"border-color:rgb(0, 85, 0);\n"
"border-radius:15px;\n"
"background: qlineargradient(spread:pad, x1:0.504808, y1:0, x2:0.51, y2:0.988636, stop:0.00480769 rgba(62, 255, 62, 255), stop:0.25 rgba(188, 255, 194, 255), stop:1 rgba(0, 156, 112, 255));\n"
"}\n"
":hover{background: qlineargradient(spread:pad, x1:0.504808, y1:0, x2:0.51, y2:0.988636, stop:0.00480769 rgba(62, 255, 62, 255), stop:0.504808 rgba(188, 255, 194, 255), stop:1 rgba(0, 156, 112, 255));}\n"
":pressed{background: qlineargradient(spread:pad, x1:0.504808, y1:0, x2:0.51, y2:0.988636, stop:0.00480769 rgba(62, 255, 62, 255), stop:0.783654 rgba(188, 255, 194, 255), stop:1 rgba(0, 156, 112, 255));}"));
        br = new QPushButton(centralwidget);
        br->setObjectName(QString::fromUtf8("br"));
        br->setGeometry(QRect(440, 370, 60, 60));
        sizePolicy.setHeightForWidth(br->sizePolicy().hasHeightForWidth());
        br->setSizePolicy(sizePolicy);
        br->setFont(font);
        br->setStyleSheet(QString::fromUtf8("QPushButton\n"
"{\n"
"text-decoration: none;\n"
"padding 0 0 0 0;\n"
"ouline:none;\n"
"border-width:2px;\n"
"border-style:solid;\n"
"border-color:rgb(230, 139, 48);\n"
"border-radius:15px;\n"
"background:qlineargradient(spread:pad, x1:0.50805, y1:0, x2:0.498, y2:1, stop:0 rgba(255, 169, 70, 255), stop:0.238806 rgba(255, 216, 152, 255), stop:1 rgba(255, 157, 59, 255));\n"
"}\n"
":hover{background:qlineargradient(spread:pad, x1:0.50805, y1:0, x2:0.498, y2:1, stop:0 rgba(255, 167, 66, 255), stop:0.492537 rgba(255, 216, 152, 255), stop:1 rgba(255, 173, 90, 255));}\n"
":pressed{background: qlineargradient(spread:pad, x1:0.50805, y1:0, x2:0.498, y2:1, stop:0 rgba(255, 162, 56, 255), stop:0.800995 rgba(255, 216, 152, 255), stop:1 rgba(255, 173, 90, 255));}"));
        bDEL = new QPushButton(centralwidget);
        bDEL->setObjectName(QString::fromUtf8("bDEL"));
        bDEL->setGeometry(QRect(160, 230, 60, 60));
        sizePolicy.setHeightForWidth(bDEL->sizePolicy().hasHeightForWidth());
        bDEL->setSizePolicy(sizePolicy);
        QFont font3;
        font3.setFamily(QString::fromUtf8("Times New Roman"));
        font3.setPointSize(15);
        font3.setBold(true);
        font3.setUnderline(false);
        font3.setWeight(75);
        font3.setStrikeOut(false);
        bDEL->setFont(font3);
        bDEL->setStyleSheet(QString::fromUtf8("QPushButton\n"
"{\n"
"text-decoration: none;\n"
"padding 0 0 0 0;\n"
"ouline:none;\n"
"border-width:2px;\n"
"border-style:solid;\n"
"border-color:rgb(199, 66, 0);\n"
"border-radius:15px;\n"
"background:qlineargradient(spread:pad, x1:0.504808, y1:0, x2:0.51, y2:0.988636, stop:0.00480769 rgba(255, 133, 46, 255), stop:0.25 rgba(255, 193, 152, 255), stop:1 rgba(244, 102, 32, 255));\n"
"}\n"
":hover{background: qlineargradient(spread:pad, x1:0.504808, y1:0, x2:0.51, y2:0.988636, stop:0.00480769 rgba(255, 133, 46, 255), stop:0.509615 rgba(255, 193, 152, 255), stop:1 rgba(244, 102, 32, 255));}\n"
":pressed{background: qlineargradient(spread:pad, x1:0.504808, y1:0, x2:0.51, y2:0.988636, stop:0.00480769 rgba(255, 133, 46, 255), stop:0.793269 rgba(255, 193, 152, 255), stop:1 rgba(244, 102, 32, 255));}"));
        b5 = new QPushButton(centralwidget);
        b5->setObjectName(QString::fromUtf8("b5"));
        b5->setGeometry(QRect(160, 370, 60, 60));
        sizePolicy.setHeightForWidth(b5->sizePolicy().hasHeightForWidth());
        b5->setSizePolicy(sizePolicy);
        b5->setFont(font);
        b5->setStyleSheet(QString::fromUtf8("QPushButton\n"
"{\n"
"text-decoration: none;\n"
"padding 0 0 0 0;\n"
"ouline:none;\n"
"border-width:2px;\n"
"border-style:solid;\n"
"border-color:rgb(0, 85, 0);\n"
"border-radius:15px;\n"
"background: qlineargradient(spread:pad, x1:0.504808, y1:0, x2:0.51, y2:0.988636, stop:0.00480769 rgba(62, 255, 62, 255), stop:0.25 rgba(188, 255, 194, 255), stop:1 rgba(0, 156, 112, 255));\n"
"}\n"
":hover{background: qlineargradient(spread:pad, x1:0.504808, y1:0, x2:0.51, y2:0.988636, stop:0.00480769 rgba(62, 255, 62, 255), stop:0.504808 rgba(188, 255, 194, 255), stop:1 rgba(0, 156, 112, 255));}\n"
":pressed{background: qlineargradient(spread:pad, x1:0.504808, y1:0, x2:0.51, y2:0.988636, stop:0.00480769 rgba(62, 255, 62, 255), stop:0.783654 rgba(188, 255, 194, 255), stop:1 rgba(0, 156, 112, 255));}"));
        bPlus = new QPushButton(centralwidget);
        bPlus->setObjectName(QString::fromUtf8("bPlus"));
        bPlus->setGeometry(QRect(300, 440, 60, 60));
        sizePolicy.setHeightForWidth(bPlus->sizePolicy().hasHeightForWidth());
        bPlus->setSizePolicy(sizePolicy);
        bPlus->setFont(font);
        bPlus->setStyleSheet(QString::fromUtf8("QPushButton\n"
"{\n"
"text-decoration: none;\n"
"padding 0 0 0 0;\n"
"ouline:none;\n"
"border-width:2px;\n"
"border-style:solid;\n"
"border-color:rgb(4, 0, 125);\n"
"border-radius:15px;\n"
"background:qlineargradient(spread:pad, x1:0.50805, y1:0, x2:0.498, y2:1, stop:0 rgba(0, 13, 255, 255), stop:0.238806 rgba(125, 188, 255, 255), stop:1 rgba(0, 0, 145, 255));\n"
"}\n"
":hover{background:qlineargradient(spread:pad, x1:0.50805, y1:0, x2:0.498, y2:1, stop:0 rgba(0, 13, 255, 255), stop:0.492537 rgba(125, 188, 255, 255), stop:1 rgba(0, 0, 145, 255));}\n"
":pressed{background: qlineargradient(spread:pad, x1:0.50805, y1:0, x2:0.498, y2:1, stop:0 rgba(0, 13, 255, 255), stop:0.791045 rgba(125, 188, 255, 255), stop:1 rgba(0, 0, 145, 255));}"));
        b6 = new QPushButton(centralwidget);
        b6->setObjectName(QString::fromUtf8("b6"));
        b6->setGeometry(QRect(230, 370, 60, 60));
        sizePolicy.setHeightForWidth(b6->sizePolicy().hasHeightForWidth());
        b6->setSizePolicy(sizePolicy);
        b6->setFont(font);
        b6->setStyleSheet(QString::fromUtf8("QPushButton\n"
"{\n"
"text-decoration: none;\n"
"padding 0 0 0 0;\n"
"ouline:none;\n"
"border-width:2px;\n"
"border-style:solid;\n"
"border-color:rgb(0, 85, 0);\n"
"border-radius:15px;\n"
"background: qlineargradient(spread:pad, x1:0.504808, y1:0, x2:0.51, y2:0.988636, stop:0.00480769 rgba(62, 255, 62, 255), stop:0.25 rgba(188, 255, 194, 255), stop:1 rgba(0, 156, 112, 255));\n"
"}\n"
":hover{background: qlineargradient(spread:pad, x1:0.504808, y1:0, x2:0.51, y2:0.988636, stop:0.00480769 rgba(62, 255, 62, 255), stop:0.504808 rgba(188, 255, 194, 255), stop:1 rgba(0, 156, 112, 255));}\n"
":pressed{background: qlineargradient(spread:pad, x1:0.504808, y1:0, x2:0.51, y2:0.988636, stop:0.00480769 rgba(62, 255, 62, 255), stop:0.783654 rgba(188, 255, 194, 255), stop:1 rgba(0, 156, 112, 255));}"));
        bClear = new QPushButton(centralwidget);
        bClear->setObjectName(QString::fromUtf8("bClear"));
        bClear->setGeometry(QRect(90, 230, 60, 60));
        sizePolicy.setHeightForWidth(bClear->sizePolicy().hasHeightForWidth());
        bClear->setSizePolicy(sizePolicy);
        bClear->setFont(font);
        bClear->setStyleSheet(QString::fromUtf8("QPushButton\n"
"{\n"
"text-decoration: none;\n"
"padding 0 0 0 0;\n"
"ouline:none;\n"
"border-width:2px;\n"
"border-style:solid;\n"
"border-color:rgb(199, 66, 0);\n"
"border-radius:15px;\n"
"background:qlineargradient(spread:pad, x1:0.504808, y1:0, x2:0.51, y2:0.988636, stop:0.00480769 rgba(255, 133, 46, 255), stop:0.25 rgba(255, 193, 152, 255), stop:1 rgba(244, 102, 32, 255));\n"
"}\n"
":hover{background: qlineargradient(spread:pad, x1:0.504808, y1:0, x2:0.51, y2:0.988636, stop:0.00480769 rgba(255, 133, 46, 255), stop:0.509615 rgba(255, 193, 152, 255), stop:1 rgba(244, 102, 32, 255));}\n"
":pressed{background: qlineargradient(spread:pad, x1:0.504808, y1:0, x2:0.51, y2:0.988636, stop:0.00480769 rgba(255, 133, 46, 255), stop:0.793269 rgba(255, 193, 152, 255), stop:1 rgba(244, 102, 32, 255));}"));
        blanguage = new QPushButton(centralwidget);
        blanguage->setObjectName(QString::fromUtf8("blanguage"));
        blanguage->setGeometry(QRect(0, 0, 51, 51));
        sizePolicy.setHeightForWidth(blanguage->sizePolicy().hasHeightForWidth());
        blanguage->setSizePolicy(sizePolicy);
        QFont font4;
        font4.setFamily(QString::fromUtf8("Times New Roman"));
        font4.setPointSize(12);
        font4.setBold(true);
        font4.setUnderline(false);
        font4.setWeight(75);
        font4.setStrikeOut(false);
        blanguage->setFont(font4);
        blanguage->setStyleSheet(QString::fromUtf8("QPushButton\n"
"{\n"
"text-decoration: none;\n"
"padding 0 0 0 0;\n"
"ouline:none;\n"
"border-width:2px;\n"
"border-style:solid;\n"
"border-color:rgb(0, 0, 127);\n"
"border-radius:15px;\n"
"background:qlineargradient(spread:pad, x1:0.50805, y1:0, x2:0.498, y2:1, stop:0 rgba(229, 229, 229, 255), stop:0.452736 rgba(252, 252, 252, 255), stop:1 rgba(212, 212, 212, 255));\n"
"}\n"
""));
        b00 = new QPushButton(centralwidget);
        b00->setObjectName(QString::fromUtf8("b00"));
        b00->setGeometry(QRect(160, 510, 60, 60));
        sizePolicy.setHeightForWidth(b00->sizePolicy().hasHeightForWidth());
        b00->setSizePolicy(sizePolicy);
        b00->setFont(font);
        b00->setStyleSheet(QString::fromUtf8("QPushButton\n"
"{\n"
"text-decoration: none;\n"
"padding 0 0 0 0;\n"
"ouline:none;\n"
"border-width:2px;\n"
"border-style:solid;\n"
"border-color:rgb(0, 85, 0);\n"
"border-radius:15px;\n"
"background: qlineargradient(spread:pad, x1:0.504808, y1:0, x2:0.51, y2:0.988636, stop:0.00480769 rgba(62, 255, 62, 255), stop:0.25 rgba(188, 255, 194, 255), stop:1 rgba(0, 156, 112, 255));\n"
"}\n"
":hover{background: qlineargradient(spread:pad, x1:0.504808, y1:0, x2:0.51, y2:0.988636, stop:0.00480769 rgba(62, 255, 62, 255), stop:0.504808 rgba(188, 255, 194, 255), stop:1 rgba(0, 156, 112, 255));}\n"
":pressed{background: qlineargradient(spread:pad, x1:0.504808, y1:0, x2:0.51, y2:0.988636, stop:0.00480769 rgba(62, 255, 62, 255), stop:0.783654 rgba(188, 255, 194, 255), stop:1 rgba(0, 156, 112, 255));}"));
        calculator->setCentralWidget(centralwidget);

        retranslateUi(calculator);

        QMetaObject::connectSlotsByName(calculator);
    } // setupUi

    void retranslateUi(QMainWindow *calculator)
    {
        calculator->setWindowTitle(QApplication::translate("calculator", "calculator", nullptr));
        b7->setText(QApplication::translate("calculator", "7", nullptr));
        bDegree->setText(QString());
        bl->setText(QApplication::translate("calculator", "(", nullptr));
        b9->setText(QApplication::translate("calculator", "9", nullptr));
        bDot->setText(QApplication::translate("calculator", ".", nullptr));
        tablo_error->setText(QString());
        b3->setText(QApplication::translate("calculator", "3", nullptr));
        bMultiply->setText(QApplication::translate("calculator", "\303\227", nullptr));
        tablo_3->setText(QApplication::translate("calculator", "0", nullptr));
        b4->setText(QApplication::translate("calculator", "4", nullptr));
        b0->setText(QApplication::translate("calculator", "0", nullptr));
        btransion->setText(QString());
        bLog->setText(QString());
        bRoot->setText(QString());
        bResult->setText(QApplication::translate("calculator", "=", nullptr));
        bDivision->setText(QApplication::translate("calculator", "\303\267", nullptr));
        b1->setText(QApplication::translate("calculator", "1", nullptr));
        tablo_1->setText(QApplication::translate("calculator", "0", nullptr));
        bMinus->setText(QApplication::translate("calculator", "-", nullptr));
        tablo_2->setText(QString());
        bdivision->setText(QString());
        bSign->setText(QApplication::translate("calculator", "\302\261", nullptr));
        b2->setText(QApplication::translate("calculator", "2", nullptr));
        b8->setText(QApplication::translate("calculator", "8", nullptr));
        br->setText(QApplication::translate("calculator", ")", nullptr));
        bDEL->setText(QApplication::translate("calculator", "DEL", nullptr));
        b5->setText(QApplication::translate("calculator", "5", nullptr));
        bPlus->setText(QApplication::translate("calculator", "+", nullptr));
        b6->setText(QApplication::translate("calculator", "6", nullptr));
        bClear->setText(QApplication::translate("calculator", "C", nullptr));
        blanguage->setText(QApplication::translate("calculator", "ENG", nullptr));
        b00->setText(QApplication::translate("calculator", "00", nullptr));
    } // retranslateUi

};

namespace Ui {
    class calculator: public Ui_calculator {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_CALCULATOR_H
