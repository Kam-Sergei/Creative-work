/********************************************************************************
** Form generated from reading UI file 'cities.ui'
**
** Created by: Qt User Interface Compiler version 5.12.10
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_CITIES_H
#define UI_CITIES_H

#include <QtCore/QVariant>
#include <QtGui/QIcon>
#include <QtWidgets/QApplication>
#include <QtWidgets/QGraphicsView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QTextEdit>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_cities
{
public:
    QWidget *centralwidget;
    QPushButton *b1;
    QLabel *lmenu;
    QLabel *l1;
    QLabel *l5;
    QPushButton *b5;
    QLabel *l6;
    QPushButton *b6;
    QLabel *l4;
    QPushButton *b4;
    QLabel *l3;
    QPushButton *b3;
    QLabel *l2;
    QPushButton *b2;
    QPushButton *bChangeSize;
    QPushButton *bSelectCities;
    QPushButton *bCreateARoute;
    QLineEdit *tablo_1;
    QPushButton *bvvod;
    QLabel *tablo_vivod;
    QLineEdit *tablo_2;
    QLineEdit *tablo_3;
    QGraphicsView *graphicsView;
    QPushButton *b11;
    QPushButton *b10;
    QPushButton *b9;
    QPushButton *b8;
    QPushButton *b12;
    QPushButton *b7;
    QPushButton *b13;
    QPushButton *b15;
    QPushButton *b14;
    QPushButton *bclear;
    QTextEdit *textEdit;
    QLabel *l11;
    QLabel *l12;
    QLabel *l14;
    QLabel *l15;
    QLabel *l7;
    QLabel *l9;
    QLabel *l8;
    QLabel *l13;
    QLabel *l10;
    QPushButton *blanguage;
    QStatusBar *statusbar;
    QMenuBar *menubar;

    void setupUi(QMainWindow *cities)
    {
        if (cities->objectName().isEmpty())
            cities->setObjectName(QString::fromUtf8("cities"));
        cities->setEnabled(true);
        cities->resize(1130, 850);
        cities->setMinimumSize(QSize(1130, 850));
        cities->setMaximumSize(QSize(1130, 850));
        QIcon icon;
        icon.addFile(QString::fromUtf8(":/images/images/Icon.png"), QSize(), QIcon::Normal, QIcon::Off);
        cities->setWindowIcon(icon);
        cities->setStyleSheet(QString::fromUtf8("QMainWindow\n"
"{\n"
"	background-image: url(:/images/images/Map.png);\n"
"}"));
        centralwidget = new QWidget(cities);
        centralwidget->setObjectName(QString::fromUtf8("centralwidget"));
        b1 = new QPushButton(centralwidget);
        b1->setObjectName(QString::fromUtf8("b1"));
        b1->setGeometry(QRect(280, 270, 41, 41));
        QFont font;
        font.setBold(true);
        font.setUnderline(false);
        font.setWeight(75);
        font.setStrikeOut(false);
        b1->setFont(font);
        b1->setStyleSheet(QString::fromUtf8("QPushButton\n"
"{\n"
"text-decoration: none;\n"
"padding 0 0 0 0;\n"
"ouline:none;\n"
"border-width:2px;\n"
"border-style:solid;\n"
"border-color:rgb(4, 0, 125);\n"
"border-radius:20px;\n"
"background:qlineargradient(spread:pad, x1:0.50805, y1:0, x2:0.498, y2:1, stop:0 rgba(0, 13, 255, 255), stop:0.238806 rgba(125, 188, 255, 255), stop:1 rgba(0, 0, 145, 255));\n"
"}\n"
":hover{background:qlineargradient(spread:pad, x1:0.50805, y1:0, x2:0.498, y2:1, stop:0 rgba(0, 13, 255, 255), stop:0.492537 rgba(125, 188, 255, 255), stop:1 rgba(0, 0, 145, 255));}\n"
":pressed{background: qlineargradient(spread:pad, x1:0.50805, y1:0, x2:0.498, y2:1, stop:0 rgba(0, 13, 255, 255), stop:0.791045 rgba(125, 188, 255, 255), stop:1 rgba(0, 0, 145, 255));}"));
        lmenu = new QLabel(centralwidget);
        lmenu->setObjectName(QString::fromUtf8("lmenu"));
        lmenu->setGeometry(QRect(870, 0, 261, 281));
        lmenu->setStyleSheet(QString::fromUtf8("QLabel\n"
"{\n"
"background:qlineargradient(spread:pad, x1:0.51, y1:0, x2:0.519, y2:1, stop:0 rgba(25, 217, 255, 255), stop:0.509615 rgba(123, 237, 255, 255), stop:1 rgba(35, 167, 255, 255));\n"
"}"));
        l1 = new QLabel(centralwidget);
        l1->setObjectName(QString::fromUtf8("l1"));
        l1->setGeometry(QRect(210, 230, 191, 31));
        QFont font1;
        font1.setPointSize(12);
        font1.setBold(true);
        font1.setItalic(false);
        font1.setUnderline(false);
        font1.setWeight(75);
        font1.setStrikeOut(false);
        l1->setFont(font1);
        l1->setStyleSheet(QString::fromUtf8("QLabel\n"
"{\n"
"color:rgb(136, 0, 2);\n"
"}"));
        l5 = new QLabel(centralwidget);
        l5->setObjectName(QString::fromUtf8("l5"));
        l5->setGeometry(QRect(190, 590, 111, 31));
        l5->setFont(font1);
        l5->setStyleSheet(QString::fromUtf8("QLabel\n"
"{\n"
"color:rgb(136, 0, 2);\n"
"}"));
        b5 = new QPushButton(centralwidget);
        b5->setObjectName(QString::fromUtf8("b5"));
        b5->setGeometry(QRect(220, 630, 41, 41));
        b5->setFont(font);
        b5->setStyleSheet(QString::fromUtf8("QPushButton\n"
"{\n"
"text-decoration: none;\n"
"padding 0 0 0 0;\n"
"ouline:none;\n"
"border-width:2px;\n"
"border-style:solid;\n"
"border-color:rgb(4, 0, 125);\n"
"border-radius:20px;\n"
"background:qlineargradient(spread:pad, x1:0.50805, y1:0, x2:0.498, y2:1, stop:0 rgba(0, 13, 255, 255), stop:0.238806 rgba(125, 188, 255, 255), stop:1 rgba(0, 0, 145, 255));\n"
"}\n"
":hover{background:qlineargradient(spread:pad, x1:0.50805, y1:0, x2:0.498, y2:1, stop:0 rgba(0, 13, 255, 255), stop:0.492537 rgba(125, 188, 255, 255), stop:1 rgba(0, 0, 145, 255));}\n"
":pressed{background: qlineargradient(spread:pad, x1:0.50805, y1:0, x2:0.498, y2:1, stop:0 rgba(0, 13, 255, 255), stop:0.791045 rgba(125, 188, 255, 255), stop:1 rgba(0, 0, 145, 255));}"));
        l6 = new QLabel(centralwidget);
        l6->setObjectName(QString::fromUtf8("l6"));
        l6->setGeometry(QRect(50, 600, 61, 31));
        l6->setFont(font1);
        l6->setStyleSheet(QString::fromUtf8("QLabel\n"
"{\n"
"color:rgb(136, 0, 2);\n"
"}"));
        b6 = new QPushButton(centralwidget);
        b6->setObjectName(QString::fromUtf8("b6"));
        b6->setGeometry(QRect(60, 640, 41, 41));
        b6->setFont(font);
        b6->setStyleSheet(QString::fromUtf8("QPushButton\n"
"{\n"
"text-decoration: none;\n"
"padding 0 0 0 0;\n"
"ouline:none;\n"
"border-width:2px;\n"
"border-style:solid;\n"
"border-color:rgb(4, 0, 125);\n"
"border-radius:20px;\n"
"background:qlineargradient(spread:pad, x1:0.50805, y1:0, x2:0.498, y2:1, stop:0 rgba(0, 13, 255, 255), stop:0.238806 rgba(125, 188, 255, 255), stop:1 rgba(0, 0, 145, 255));\n"
"}\n"
":hover{background:qlineargradient(spread:pad, x1:0.50805, y1:0, x2:0.498, y2:1, stop:0 rgba(0, 13, 255, 255), stop:0.492537 rgba(125, 188, 255, 255), stop:1 rgba(0, 0, 145, 255));}\n"
":pressed{background: qlineargradient(spread:pad, x1:0.50805, y1:0, x2:0.498, y2:1, stop:0 rgba(0, 13, 255, 255), stop:0.791045 rgba(125, 188, 255, 255), stop:1 rgba(0, 0, 145, 255));}"));
        l4 = new QLabel(centralwidget);
        l4->setObjectName(QString::fromUtf8("l4"));
        l4->setGeometry(QRect(590, 580, 91, 31));
        l4->setFont(font1);
        l4->setStyleSheet(QString::fromUtf8("QLabel\n"
"{\n"
"color:rgb(136, 0, 2);\n"
"}"));
        b4 = new QPushButton(centralwidget);
        b4->setObjectName(QString::fromUtf8("b4"));
        b4->setGeometry(QRect(610, 620, 41, 41));
        b4->setFont(font);
        b4->setStyleSheet(QString::fromUtf8("QPushButton\n"
"{\n"
"text-decoration: none;\n"
"padding 0 0 0 0;\n"
"ouline:none;\n"
"border-width:2px;\n"
"border-style:solid;\n"
"border-color:rgb(4, 0, 125);\n"
"border-radius:20px;\n"
"background:qlineargradient(spread:pad, x1:0.50805, y1:0, x2:0.498, y2:1, stop:0 rgba(0, 13, 255, 255), stop:0.238806 rgba(125, 188, 255, 255), stop:1 rgba(0, 0, 145, 255));\n"
"}\n"
":hover{background:qlineargradient(spread:pad, x1:0.50805, y1:0, x2:0.498, y2:1, stop:0 rgba(0, 13, 255, 255), stop:0.492537 rgba(125, 188, 255, 255), stop:1 rgba(0, 0, 145, 255));}\n"
":pressed{background: qlineargradient(spread:pad, x1:0.50805, y1:0, x2:0.498, y2:1, stop:0 rgba(0, 13, 255, 255), stop:0.791045 rgba(125, 188, 255, 255), stop:1 rgba(0, 0, 145, 255));}"));
        l3 = new QLabel(centralwidget);
        l3->setObjectName(QString::fromUtf8("l3"));
        l3->setGeometry(QRect(520, 480, 71, 31));
        l3->setFont(font1);
        l3->setStyleSheet(QString::fromUtf8("QLabel\n"
"{\n"
"color:rgb(136, 0, 2);\n"
"}"));
        b3 = new QPushButton(centralwidget);
        b3->setObjectName(QString::fromUtf8("b3"));
        b3->setGeometry(QRect(530, 520, 41, 41));
        b3->setFont(font);
        b3->setStyleSheet(QString::fromUtf8("QPushButton\n"
"{\n"
"text-decoration: none;\n"
"padding 0 0 0 0;\n"
"ouline:none;\n"
"border-width:2px;\n"
"border-style:solid;\n"
"border-color:rgb(4, 0, 125);\n"
"border-radius:20px;\n"
"background:qlineargradient(spread:pad, x1:0.50805, y1:0, x2:0.498, y2:1, stop:0 rgba(0, 13, 255, 255), stop:0.238806 rgba(125, 188, 255, 255), stop:1 rgba(0, 0, 145, 255));\n"
"}\n"
":hover{background:qlineargradient(spread:pad, x1:0.50805, y1:0, x2:0.498, y2:1, stop:0 rgba(0, 13, 255, 255), stop:0.492537 rgba(125, 188, 255, 255), stop:1 rgba(0, 0, 145, 255));}\n"
":pressed{background: qlineargradient(spread:pad, x1:0.50805, y1:0, x2:0.498, y2:1, stop:0 rgba(0, 13, 255, 255), stop:0.791045 rgba(125, 188, 255, 255), stop:1 rgba(0, 0, 145, 255));}"));
        l2 = new QLabel(centralwidget);
        l2->setObjectName(QString::fromUtf8("l2"));
        l2->setGeometry(QRect(260, 380, 81, 31));
        l2->setFont(font1);
        l2->setStyleSheet(QString::fromUtf8("QLabel\n"
"{\n"
"color:rgb(136, 0, 2);\n"
"}"));
        b2 = new QPushButton(centralwidget);
        b2->setObjectName(QString::fromUtf8("b2"));
        b2->setGeometry(QRect(280, 420, 41, 41));
        b2->setFont(font);
        b2->setStyleSheet(QString::fromUtf8("QPushButton\n"
"{\n"
"text-decoration: none;\n"
"padding 0 0 0 0;\n"
"ouline:none;\n"
"border-width:2px;\n"
"border-style:solid;\n"
"border-color:rgb(4, 0, 125);\n"
"border-radius:20px;\n"
"background:qlineargradient(spread:pad, x1:0.50805, y1:0, x2:0.498, y2:1, stop:0 rgba(0, 13, 255, 255), stop:0.238806 rgba(125, 188, 255, 255), stop:1 rgba(0, 0, 145, 255));\n"
"}\n"
":hover{background:qlineargradient(spread:pad, x1:0.50805, y1:0, x2:0.498, y2:1, stop:0 rgba(0, 13, 255, 255), stop:0.492537 rgba(125, 188, 255, 255), stop:1 rgba(0, 0, 145, 255));}\n"
":pressed{background: qlineargradient(spread:pad, x1:0.50805, y1:0, x2:0.498, y2:1, stop:0 rgba(0, 13, 255, 255), stop:0.791045 rgba(125, 188, 255, 255), stop:1 rgba(0, 0, 145, 255));}"));
        bChangeSize = new QPushButton(centralwidget);
        bChangeSize->setObjectName(QString::fromUtf8("bChangeSize"));
        bChangeSize->setGeometry(QRect(890, 70, 221, 51));
        QFont font2;
        font2.setPointSize(9);
        font2.setBold(true);
        font2.setUnderline(false);
        font2.setWeight(75);
        font2.setStrikeOut(false);
        bChangeSize->setFont(font2);
        bChangeSize->setStyleSheet(QString::fromUtf8("QPushButton\n"
"{\n"
"text-decoration: none;\n"
"padding 0 0 0 0;\n"
"ouline:none;\n"
"border-width:2px;\n"
"border-style:solid;\n"
"border-color:rgb(0, 85, 0);\n"
"border-radius:15px;\n"
"background: qlineargradient(spread:pad, x1:0.504808, y1:0, x2:0.51, y2:0.988636, stop:0.00480769 rgba(62, 255, 62, 255), stop:0.25 rgba(188, 255, 194, 255), stop:1 rgba(0, 156, 112, 255));\n"
"}\n"
":hover{background: qlineargradient(spread:pad, x1:0.504808, y1:0, x2:0.51, y2:0.988636, stop:0.00480769 rgba(62, 255, 62, 255), stop:0.504808 rgba(188, 255, 194, 255), stop:1 rgba(0, 156, 112, 255));}\n"
":pressed{background: qlineargradient(spread:pad, x1:0.504808, y1:0, x2:0.51, y2:0.988636, stop:0.00480769 rgba(62, 255, 62, 255), stop:0.783654 rgba(188, 255, 194, 255), stop:1 rgba(0, 156, 112, 255));}"));
        bSelectCities = new QPushButton(centralwidget);
        bSelectCities->setObjectName(QString::fromUtf8("bSelectCities"));
        bSelectCities->setGeometry(QRect(890, 10, 221, 51));
        bSelectCities->setFont(font2);
        bSelectCities->setStyleSheet(QString::fromUtf8("QPushButton\n"
"{\n"
"text-decoration: none;\n"
"padding 0 0 0 0;\n"
"ouline:none;\n"
"border-width:2px;\n"
"border-style:solid;\n"
"border-color:rgb(0, 85, 0);\n"
"border-radius:15px;\n"
"background: qlineargradient(spread:pad, x1:0.504808, y1:0, x2:0.51, y2:0.988636, stop:0.00480769 rgba(62, 255, 62, 255), stop:0.25 rgba(188, 255, 194, 255), stop:1 rgba(0, 156, 112, 255));\n"
"}\n"
":hover{background: qlineargradient(spread:pad, x1:0.504808, y1:0, x2:0.51, y2:0.988636, stop:0.00480769 rgba(62, 255, 62, 255), stop:0.504808 rgba(188, 255, 194, 255), stop:1 rgba(0, 156, 112, 255));}\n"
":pressed{background: qlineargradient(spread:pad, x1:0.504808, y1:0, x2:0.51, y2:0.988636, stop:0.00480769 rgba(62, 255, 62, 255), stop:0.783654 rgba(188, 255, 194, 255), stop:1 rgba(0, 156, 112, 255));}"));
        bCreateARoute = new QPushButton(centralwidget);
        bCreateARoute->setObjectName(QString::fromUtf8("bCreateARoute"));
        bCreateARoute->setGeometry(QRect(890, 130, 221, 51));
        bCreateARoute->setFont(font2);
        bCreateARoute->setStyleSheet(QString::fromUtf8("QPushButton\n"
"{\n"
"text-decoration: none;\n"
"padding 0 0 0 0;\n"
"ouline:none;\n"
"border-width:2px;\n"
"border-style:solid;\n"
"border-color:rgb(0, 85, 0);\n"
"border-radius:15px;\n"
"background: qlineargradient(spread:pad, x1:0.504808, y1:0, x2:0.51, y2:0.988636, stop:0.00480769 rgba(62, 255, 62, 255), stop:0.25 rgba(188, 255, 194, 255), stop:1 rgba(0, 156, 112, 255));\n"
"}\n"
":hover{background: qlineargradient(spread:pad, x1:0.504808, y1:0, x2:0.51, y2:0.988636, stop:0.00480769 rgba(62, 255, 62, 255), stop:0.504808 rgba(188, 255, 194, 255), stop:1 rgba(0, 156, 112, 255));}\n"
":pressed{background: qlineargradient(spread:pad, x1:0.504808, y1:0, x2:0.51, y2:0.988636, stop:0.00480769 rgba(62, 255, 62, 255), stop:0.783654 rgba(188, 255, 194, 255), stop:1 rgba(0, 156, 112, 255));}"));
        tablo_1 = new QLineEdit(centralwidget);
        tablo_1->setObjectName(QString::fromUtf8("tablo_1"));
        tablo_1->setGeometry(QRect(60, 50, 411, 51));
        QFont font3;
        font3.setFamily(QString::fromUtf8("Times New Roman"));
        font3.setPointSize(20);
        font3.setBold(true);
        font3.setUnderline(false);
        font3.setWeight(75);
        font3.setStrikeOut(false);
        tablo_1->setFont(font3);
        tablo_1->setLayoutDirection(Qt::LeftToRight);
        tablo_1->setStyleSheet(QString::fromUtf8("QLineEdit\n"
"{\n"
"text-decoration: none;\n"
"padding 0 0 0 0;\n"
"ouline:none;\n"
"border-width:2px;\n"
"border-style:solid;\n"
"border-color:rgb(234, 234, 234);\n"
"border-radius:5px;\n"
"background:qlineargradient(spread:pad, x1:0.50805, y1:0, x2:0.498, y2:1, stop:0 rgba(229, 229, 229, 255), stop:0.452736 rgba(252, 252, 252, 255), stop:1 rgba(212, 212, 212, 255));\n"
"}\n"
""));
        tablo_1->setMaxLength(32767);
        tablo_1->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);
        bvvod = new QPushButton(centralwidget);
        bvvod->setObjectName(QString::fromUtf8("bvvod"));
        bvvod->setGeometry(QRect(490, 50, 71, 51));
        bvvod->setFont(font2);
        bvvod->setStyleSheet(QString::fromUtf8("QPushButton\n"
"{\n"
"text-decoration: none;\n"
"padding 0 0 0 0;\n"
"ouline:none;\n"
"border-width:2px;\n"
"border-style:solid;\n"
"border-color:rgb(230, 139, 48);\n"
"border-radius:15px;\n"
"background:qlineargradient(spread:pad, x1:0.50805, y1:0, x2:0.498, y2:1, stop:0 rgba(255, 169, 70, 255), stop:0.238806 rgba(255, 216, 152, 255), stop:1 rgba(255, 157, 59, 255));\n"
"}\n"
":hover{background:qlineargradient(spread:pad, x1:0.50805, y1:0, x2:0.498, y2:1, stop:0 rgba(255, 167, 66, 255), stop:0.492537 rgba(255, 216, 152, 255), stop:1 rgba(255, 173, 90, 255));}\n"
":pressed{background: qlineargradient(spread:pad, x1:0.50805, y1:0, x2:0.498, y2:1, stop:0 rgba(255, 162, 56, 255), stop:0.800995 rgba(255, 216, 152, 255), stop:1 rgba(255, 173, 90, 255));}"));
        tablo_vivod = new QLabel(centralwidget);
        tablo_vivod->setObjectName(QString::fromUtf8("tablo_vivod"));
        tablo_vivod->setGeometry(QRect(60, 0, 801, 51));
        QFont font4;
        font4.setFamily(QString::fromUtf8("Times New Roman"));
        font4.setPointSize(15);
        font4.setBold(true);
        font4.setUnderline(true);
        font4.setWeight(75);
        tablo_vivod->setFont(font4);
        tablo_vivod->setStyleSheet(QString::fromUtf8("QLabel\n"
"{\n"
"color:rgb(129, 31, 31)\n"
"}"));
        tablo_vivod->setAlignment(Qt::AlignCenter);
        tablo_2 = new QLineEdit(centralwidget);
        tablo_2->setObjectName(QString::fromUtf8("tablo_2"));
        tablo_2->setGeometry(QRect(860, 550, 271, 41));
        QFont font5;
        font5.setFamily(QString::fromUtf8("Times New Roman"));
        font5.setPointSize(10);
        font5.setBold(true);
        font5.setUnderline(false);
        font5.setWeight(75);
        font5.setStrikeOut(false);
        tablo_2->setFont(font5);
        tablo_2->setLayoutDirection(Qt::LeftToRight);
        tablo_2->setStyleSheet(QString::fromUtf8("QLineEdit\n"
"{\n"
"text-decoration: none;\n"
"padding 0 0 0 0;\n"
"ouline:none;\n"
"border-width:2px;\n"
"border-style:solid;\n"
"border-color:rgb(234, 234, 234);\n"
"border-radius:5px;\n"
"background:qlineargradient(spread:pad, x1:0.50805, y1:0, x2:0.498, y2:1, stop:0 rgba(229, 229, 229, 255), stop:0.452736 rgba(252, 252, 252, 255), stop:1 rgba(212, 212, 212, 255));\n"
"}\n"
""));
        tablo_2->setMaxLength(32767);
        tablo_2->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);
        tablo_3 = new QLineEdit(centralwidget);
        tablo_3->setObjectName(QString::fromUtf8("tablo_3"));
        tablo_3->setGeometry(QRect(860, 600, 271, 41));
        tablo_3->setFont(font5);
        tablo_3->setLayoutDirection(Qt::LeftToRight);
        tablo_3->setStyleSheet(QString::fromUtf8("QLineEdit\n"
"{\n"
"text-decoration: none;\n"
"padding 0 0 0 0;\n"
"ouline:none;\n"
"border-width:2px;\n"
"border-style:solid;\n"
"border-color:rgb(234, 234, 234);\n"
"border-radius:5px;\n"
"background:qlineargradient(spread:pad, x1:0.50805, y1:0, x2:0.498, y2:1, stop:0 rgba(229, 229, 229, 255), stop:0.452736 rgba(252, 252, 252, 255), stop:1 rgba(212, 212, 212, 255));\n"
"}\n"
""));
        tablo_3->setMaxLength(32767);
        tablo_3->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);
        graphicsView = new QGraphicsView(centralwidget);
        graphicsView->setObjectName(QString::fromUtf8("graphicsView"));
        graphicsView->setGeometry(QRect(0, 0, 1131, 821));
        graphicsView->setMinimumSize(QSize(1131, 821));
        graphicsView->setMaximumSize(QSize(1131, 821));
        QFont font6;
        font6.setPointSize(9);
        font6.setBold(true);
        font6.setWeight(75);
        graphicsView->setFont(font6);
        graphicsView->setStyleSheet(QString::fromUtf8("QGraphicsView\n"
"{\n"
" background: rgba(255,255,255,0);\n"
"\n"
"}"));
        b11 = new QPushButton(centralwidget);
        b11->setObjectName(QString::fromUtf8("b11"));
        b11->setGeometry(QRect(500, 190, 41, 41));
        b11->setFont(font);
        b11->setStyleSheet(QString::fromUtf8("QPushButton\n"
"{\n"
"text-decoration: none;\n"
"padding 0 0 0 0;\n"
"ouline:none;\n"
"border-width:2px;\n"
"border-style:solid;\n"
"border-color:rgb(4, 0, 125);\n"
"border-radius:20px;\n"
"background:qlineargradient(spread:pad, x1:0.50805, y1:0, x2:0.498, y2:1, stop:0 rgba(0, 13, 255, 255), stop:0.238806 rgba(125, 188, 255, 255), stop:1 rgba(0, 0, 145, 255));\n"
"}\n"
":hover{background:qlineargradient(spread:pad, x1:0.50805, y1:0, x2:0.498, y2:1, stop:0 rgba(0, 13, 255, 255), stop:0.492537 rgba(125, 188, 255, 255), stop:1 rgba(0, 0, 145, 255));}\n"
":pressed{background: qlineargradient(spread:pad, x1:0.50805, y1:0, x2:0.498, y2:1, stop:0 rgba(0, 13, 255, 255), stop:0.791045 rgba(125, 188, 255, 255), stop:1 rgba(0, 0, 145, 255));}"));
        b10 = new QPushButton(centralwidget);
        b10->setObjectName(QString::fromUtf8("b10"));
        b10->setGeometry(QRect(460, 320, 41, 41));
        b10->setFont(font);
        b10->setStyleSheet(QString::fromUtf8("QPushButton\n"
"{\n"
"text-decoration: none;\n"
"padding 0 0 0 0;\n"
"ouline:none;\n"
"border-width:2px;\n"
"border-style:solid;\n"
"border-color:rgb(4, 0, 125);\n"
"border-radius:20px;\n"
"background:qlineargradient(spread:pad, x1:0.50805, y1:0, x2:0.498, y2:1, stop:0 rgba(0, 13, 255, 255), stop:0.238806 rgba(125, 188, 255, 255), stop:1 rgba(0, 0, 145, 255));\n"
"}\n"
":hover{background:qlineargradient(spread:pad, x1:0.50805, y1:0, x2:0.498, y2:1, stop:0 rgba(0, 13, 255, 255), stop:0.492537 rgba(125, 188, 255, 255), stop:1 rgba(0, 0, 145, 255));}\n"
":pressed{background: qlineargradient(spread:pad, x1:0.50805, y1:0, x2:0.498, y2:1, stop:0 rgba(0, 13, 255, 255), stop:0.791045 rgba(125, 188, 255, 255), stop:1 rgba(0, 0, 145, 255));}"));
        b9 = new QPushButton(centralwidget);
        b9->setObjectName(QString::fromUtf8("b9"));
        b9->setGeometry(QRect(190, 510, 41, 41));
        b9->setFont(font);
        b9->setStyleSheet(QString::fromUtf8("QPushButton\n"
"{\n"
"text-decoration: none;\n"
"padding 0 0 0 0;\n"
"ouline:none;\n"
"border-width:2px;\n"
"border-style:solid;\n"
"border-color:rgb(4, 0, 125);\n"
"border-radius:20px;\n"
"background:qlineargradient(spread:pad, x1:0.50805, y1:0, x2:0.498, y2:1, stop:0 rgba(0, 13, 255, 255), stop:0.238806 rgba(125, 188, 255, 255), stop:1 rgba(0, 0, 145, 255));\n"
"}\n"
":hover{background:qlineargradient(spread:pad, x1:0.50805, y1:0, x2:0.498, y2:1, stop:0 rgba(0, 13, 255, 255), stop:0.492537 rgba(125, 188, 255, 255), stop:1 rgba(0, 0, 145, 255));}\n"
":pressed{background: qlineargradient(spread:pad, x1:0.50805, y1:0, x2:0.498, y2:1, stop:0 rgba(0, 13, 255, 255), stop:0.791045 rgba(125, 188, 255, 255), stop:1 rgba(0, 0, 145, 255));}"));
        b8 = new QPushButton(centralwidget);
        b8->setObjectName(QString::fromUtf8("b8"));
        b8->setGeometry(QRect(380, 560, 41, 41));
        b8->setFont(font);
        b8->setStyleSheet(QString::fromUtf8("QPushButton\n"
"{\n"
"text-decoration: none;\n"
"padding 0 0 0 0;\n"
"ouline:none;\n"
"border-width:2px;\n"
"border-style:solid;\n"
"border-color:rgb(4, 0, 125);\n"
"border-radius:20px;\n"
"background:qlineargradient(spread:pad, x1:0.50805, y1:0, x2:0.498, y2:1, stop:0 rgba(0, 13, 255, 255), stop:0.238806 rgba(125, 188, 255, 255), stop:1 rgba(0, 0, 145, 255));\n"
"}\n"
":hover{background:qlineargradient(spread:pad, x1:0.50805, y1:0, x2:0.498, y2:1, stop:0 rgba(0, 13, 255, 255), stop:0.492537 rgba(125, 188, 255, 255), stop:1 rgba(0, 0, 145, 255));}\n"
":pressed{background: qlineargradient(spread:pad, x1:0.50805, y1:0, x2:0.498, y2:1, stop:0 rgba(0, 13, 255, 255), stop:0.791045 rgba(125, 188, 255, 255), stop:1 rgba(0, 0, 145, 255));}"));
        b12 = new QPushButton(centralwidget);
        b12->setObjectName(QString::fromUtf8("b12"));
        b12->setGeometry(QRect(660, 380, 41, 41));
        b12->setFont(font);
        b12->setStyleSheet(QString::fromUtf8("QPushButton\n"
"{\n"
"text-decoration: none;\n"
"padding 0 0 0 0;\n"
"ouline:none;\n"
"border-width:2px;\n"
"border-style:solid;\n"
"border-color:rgb(4, 0, 125);\n"
"border-radius:20px;\n"
"background:qlineargradient(spread:pad, x1:0.50805, y1:0, x2:0.498, y2:1, stop:0 rgba(0, 13, 255, 255), stop:0.238806 rgba(125, 188, 255, 255), stop:1 rgba(0, 0, 145, 255));\n"
"}\n"
":hover{background:qlineargradient(spread:pad, x1:0.50805, y1:0, x2:0.498, y2:1, stop:0 rgba(0, 13, 255, 255), stop:0.492537 rgba(125, 188, 255, 255), stop:1 rgba(0, 0, 145, 255));}\n"
":pressed{background: qlineargradient(spread:pad, x1:0.50805, y1:0, x2:0.498, y2:1, stop:0 rgba(0, 13, 255, 255), stop:0.791045 rgba(125, 188, 255, 255), stop:1 rgba(0, 0, 145, 255));}"));
        b7 = new QPushButton(centralwidget);
        b7->setObjectName(QString::fromUtf8("b7"));
        b7->setGeometry(QRect(200, 730, 41, 41));
        b7->setFont(font);
        b7->setStyleSheet(QString::fromUtf8("QPushButton\n"
"{\n"
"text-decoration: none;\n"
"padding 0 0 0 0;\n"
"ouline:none;\n"
"border-width:2px;\n"
"border-style:solid;\n"
"border-color:rgb(4, 0, 125);\n"
"border-radius:20px;\n"
"background:qlineargradient(spread:pad, x1:0.50805, y1:0, x2:0.498, y2:1, stop:0 rgba(0, 13, 255, 255), stop:0.238806 rgba(125, 188, 255, 255), stop:1 rgba(0, 0, 145, 255));\n"
"}\n"
":hover{background:qlineargradient(spread:pad, x1:0.50805, y1:0, x2:0.498, y2:1, stop:0 rgba(0, 13, 255, 255), stop:0.492537 rgba(125, 188, 255, 255), stop:1 rgba(0, 0, 145, 255));}\n"
":pressed{background: qlineargradient(spread:pad, x1:0.50805, y1:0, x2:0.498, y2:1, stop:0 rgba(0, 13, 255, 255), stop:0.791045 rgba(125, 188, 255, 255), stop:1 rgba(0, 0, 145, 255));}"));
        b7->setIconSize(QSize(25, 25));
        b13 = new QPushButton(centralwidget);
        b13->setObjectName(QString::fromUtf8("b13"));
        b13->setGeometry(QRect(700, 740, 41, 41));
        b13->setFont(font);
        b13->setStyleSheet(QString::fromUtf8("QPushButton\n"
"{\n"
"text-decoration: none;\n"
"padding 0 0 0 0;\n"
"ouline:none;\n"
"border-width:2px;\n"
"border-style:solid;\n"
"border-color:rgb(4, 0, 125);\n"
"border-radius:20px;\n"
"background:qlineargradient(spread:pad, x1:0.50805, y1:0, x2:0.498, y2:1, stop:0 rgba(0, 13, 255, 255), stop:0.238806 rgba(125, 188, 255, 255), stop:1 rgba(0, 0, 145, 255));\n"
"}\n"
":hover{background:qlineargradient(spread:pad, x1:0.50805, y1:0, x2:0.498, y2:1, stop:0 rgba(0, 13, 255, 255), stop:0.492537 rgba(125, 188, 255, 255), stop:1 rgba(0, 0, 145, 255));}\n"
":pressed{background: qlineargradient(spread:pad, x1:0.50805, y1:0, x2:0.498, y2:1, stop:0 rgba(0, 13, 255, 255), stop:0.791045 rgba(125, 188, 255, 255), stop:1 rgba(0, 0, 145, 255));}"));
        b15 = new QPushButton(centralwidget);
        b15->setObjectName(QString::fromUtf8("b15"));
        b15->setGeometry(QRect(750, 570, 41, 41));
        b15->setFont(font);
        b15->setStyleSheet(QString::fromUtf8("QPushButton\n"
"{\n"
"text-decoration: none;\n"
"padding 0 0 0 0;\n"
"ouline:none;\n"
"border-width:2px;\n"
"border-style:solid;\n"
"border-color:rgb(4, 0, 125);\n"
"border-radius:20px;\n"
"background:qlineargradient(spread:pad, x1:0.50805, y1:0, x2:0.498, y2:1, stop:0 rgba(0, 13, 255, 255), stop:0.238806 rgba(125, 188, 255, 255), stop:1 rgba(0, 0, 145, 255));\n"
"}\n"
":hover{background:qlineargradient(spread:pad, x1:0.50805, y1:0, x2:0.498, y2:1, stop:0 rgba(0, 13, 255, 255), stop:0.492537 rgba(125, 188, 255, 255), stop:1 rgba(0, 0, 145, 255));}\n"
":pressed{background: qlineargradient(spread:pad, x1:0.50805, y1:0, x2:0.498, y2:1, stop:0 rgba(0, 13, 255, 255), stop:0.791045 rgba(125, 188, 255, 255), stop:1 rgba(0, 0, 145, 255));}"));
        b14 = new QPushButton(centralwidget);
        b14->setObjectName(QString::fromUtf8("b14"));
        b14->setGeometry(QRect(820, 460, 41, 41));
        b14->setFont(font);
        b14->setStyleSheet(QString::fromUtf8("QPushButton\n"
"{\n"
"text-decoration: none;\n"
"padding 0 0 0 0;\n"
"ouline:none;\n"
"border-width:2px;\n"
"border-style:solid;\n"
"border-color:rgb(4, 0, 125);\n"
"border-radius:20px;\n"
"background:qlineargradient(spread:pad, x1:0.50805, y1:0, x2:0.498, y2:1, stop:0 rgba(0, 13, 255, 255), stop:0.238806 rgba(125, 188, 255, 255), stop:1 rgba(0, 0, 145, 255));\n"
"}\n"
":hover{background:qlineargradient(spread:pad, x1:0.50805, y1:0, x2:0.498, y2:1, stop:0 rgba(0, 13, 255, 255), stop:0.492537 rgba(125, 188, 255, 255), stop:1 rgba(0, 0, 145, 255));}\n"
":pressed{background: qlineargradient(spread:pad, x1:0.50805, y1:0, x2:0.498, y2:1, stop:0 rgba(0, 13, 255, 255), stop:0.791045 rgba(125, 188, 255, 255), stop:1 rgba(0, 0, 145, 255));}"));
        bclear = new QPushButton(centralwidget);
        bclear->setObjectName(QString::fromUtf8("bclear"));
        bclear->setGeometry(QRect(890, 210, 221, 51));
        bclear->setFont(font2);
        bclear->setStyleSheet(QString::fromUtf8("QPushButton\n"
"{\n"
"text-decoration: none;\n"
"padding 0 0 0 0;\n"
"ouline:none;\n"
"border-width:2px;\n"
"border-style:solid;\n"
"border-color:rgb(199, 66, 0);\n"
"border-radius:15px;\n"
"background:qlineargradient(spread:pad, x1:0.504808, y1:0, x2:0.51, y2:0.988636, stop:0.00480769 rgba(255, 133, 46, 255), stop:0.25 rgba(255, 193, 152, 255), stop:1 rgba(244, 102, 32, 255));\n"
"}\n"
":hover{background: qlineargradient(spread:pad, x1:0.504808, y1:0, x2:0.51, y2:0.988636, stop:0.00480769 rgba(255, 133, 46, 255), stop:0.509615 rgba(255, 193, 152, 255), stop:1 rgba(244, 102, 32, 255));}\n"
":pressed{background: qlineargradient(spread:pad, x1:0.504808, y1:0, x2:0.51, y2:0.988636, stop:0.00480769 rgba(255, 133, 46, 255), stop:0.793269 rgba(255, 193, 152, 255), stop:1 rgba(244, 102, 32, 255));}"));
        textEdit = new QTextEdit(centralwidget);
        textEdit->setObjectName(QString::fromUtf8("textEdit"));
        textEdit->setGeometry(QRect(800, 650, 331, 241));
        textEdit->setFont(font);
        textEdit->setStyleSheet(QString::fromUtf8("QTextEdit\n"
"{\n"
"text-decoration: none;\n"
"padding 0 0 0 0;\n"
"ouline:none;\n"
"border-width:2px;\n"
"border-style:solid;\n"
"border-color:rgb(234, 234, 234);\n"
"border-radius:5px;\n"
"background:qlineargradient(spread:pad, x1:0.50805, y1:0, x2:0.498, y2:1, stop:0 rgba(229, 229, 229, 255), stop:0.452736 rgba(252, 252, 252, 255), stop:1 rgba(212, 212, 212, 255));\n"
"}\n"
""));
        l11 = new QLabel(centralwidget);
        l11->setObjectName(QString::fromUtf8("l11"));
        l11->setGeometry(QRect(470, 150, 111, 31));
        l11->setFont(font1);
        l11->setStyleSheet(QString::fromUtf8("QLabel\n"
"{\n"
"color:rgb(136, 0, 2);\n"
"}"));
        l12 = new QLabel(centralwidget);
        l12->setObjectName(QString::fromUtf8("l12"));
        l12->setGeometry(QRect(630, 340, 91, 31));
        l12->setFont(font1);
        l12->setStyleSheet(QString::fromUtf8("QLabel\n"
"{\n"
"color:rgb(136, 0, 2);\n"
"}"));
        l14 = new QLabel(centralwidget);
        l14->setObjectName(QString::fromUtf8("l14"));
        l14->setGeometry(QRect(780, 420, 141, 31));
        l14->setFont(font1);
        l14->setStyleSheet(QString::fromUtf8("QLabel\n"
"{\n"
"color:rgb(136, 0, 2);\n"
"}"));
        l15 = new QLabel(centralwidget);
        l15->setObjectName(QString::fromUtf8("l15"));
        l15->setGeometry(QRect(740, 530, 81, 31));
        l15->setFont(font1);
        l15->setStyleSheet(QString::fromUtf8("QLabel\n"
"{\n"
"color:rgb(136, 0, 2);\n"
"}"));
        l7 = new QLabel(centralwidget);
        l7->setObjectName(QString::fromUtf8("l7"));
        l7->setGeometry(QRect(170, 690, 111, 31));
        l7->setFont(font1);
        l7->setStyleSheet(QString::fromUtf8("QLabel\n"
"{\n"
"color:rgb(136, 0, 2);\n"
"}"));
        l9 = new QLabel(centralwidget);
        l9->setObjectName(QString::fromUtf8("l9"));
        l9->setGeometry(QRect(160, 470, 101, 31));
        l9->setFont(font1);
        l9->setStyleSheet(QString::fromUtf8("QLabel\n"
"{\n"
"color:rgb(136, 0, 2);\n"
"}"));
        l8 = new QLabel(centralwidget);
        l8->setObjectName(QString::fromUtf8("l8"));
        l8->setGeometry(QRect(370, 520, 81, 31));
        l8->setFont(font1);
        l8->setStyleSheet(QString::fromUtf8("QLabel\n"
"{\n"
"color:rgb(136, 0, 2);\n"
"}"));
        l13 = new QLabel(centralwidget);
        l13->setObjectName(QString::fromUtf8("l13"));
        l13->setGeometry(QRect(690, 700, 61, 31));
        l13->setFont(font1);
        l13->setStyleSheet(QString::fromUtf8("QLabel\n"
"{\n"
"color:rgb(136, 0, 2);\n"
"}"));
        l10 = new QLabel(centralwidget);
        l10->setObjectName(QString::fromUtf8("l10"));
        l10->setGeometry(QRect(410, 280, 141, 31));
        l10->setFont(font1);
        l10->setStyleSheet(QString::fromUtf8("QLabel\n"
"{\n"
"color:rgb(136, 0, 2);\n"
"}"));
        blanguage = new QPushButton(centralwidget);
        blanguage->setObjectName(QString::fromUtf8("blanguage"));
        blanguage->setGeometry(QRect(0, 0, 51, 51));
        QSizePolicy sizePolicy(QSizePolicy::Fixed, QSizePolicy::Fixed);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(blanguage->sizePolicy().hasHeightForWidth());
        blanguage->setSizePolicy(sizePolicy);
        QFont font7;
        font7.setFamily(QString::fromUtf8("Times New Roman"));
        font7.setPointSize(12);
        font7.setBold(true);
        font7.setUnderline(false);
        font7.setWeight(75);
        font7.setStrikeOut(false);
        blanguage->setFont(font7);
        blanguage->setStyleSheet(QString::fromUtf8("QPushButton\n"
"{\n"
"text-decoration: none;\n"
"padding 0 0 0 0;\n"
"ouline:none;\n"
"border-width:2px;\n"
"border-style:solid;\n"
"border-color:rgb(0, 0, 127);\n"
"border-radius:15px;\n"
"background:qlineargradient(spread:pad, x1:0.50805, y1:0, x2:0.498, y2:1, stop:0 rgba(229, 229, 229, 255), stop:0.452736 rgba(252, 252, 252, 255), stop:1 rgba(212, 212, 212, 255));\n"
"}\n"
""));
        cities->setCentralWidget(centralwidget);
        graphicsView->raise();
        b1->raise();
        lmenu->raise();
        l1->raise();
        l5->raise();
        b5->raise();
        l6->raise();
        b6->raise();
        l4->raise();
        b4->raise();
        l3->raise();
        b3->raise();
        l2->raise();
        b2->raise();
        bChangeSize->raise();
        bSelectCities->raise();
        bCreateARoute->raise();
        tablo_1->raise();
        bvvod->raise();
        tablo_vivod->raise();
        tablo_2->raise();
        tablo_3->raise();
        b11->raise();
        b10->raise();
        b9->raise();
        b8->raise();
        b12->raise();
        b7->raise();
        b13->raise();
        b15->raise();
        b14->raise();
        bclear->raise();
        textEdit->raise();
        l11->raise();
        l12->raise();
        l14->raise();
        l15->raise();
        l7->raise();
        l9->raise();
        l8->raise();
        l13->raise();
        l10->raise();
        blanguage->raise();
        statusbar = new QStatusBar(cities);
        statusbar->setObjectName(QString::fromUtf8("statusbar"));
        cities->setStatusBar(statusbar);
        menubar = new QMenuBar(cities);
        menubar->setObjectName(QString::fromUtf8("menubar"));
        menubar->setGeometry(QRect(0, 0, 1130, 26));
        cities->setMenuBar(menubar);

        retranslateUi(cities);

        QMetaObject::connectSlotsByName(cities);
    } // setupUi

    void retranslateUi(QMainWindow *cities)
    {
        cities->setWindowTitle(QApplication::translate("cities", "cities", nullptr));
        b1->setText(QApplication::translate("cities", "1", nullptr));
        lmenu->setText(QString());
        l1->setText(QApplication::translate("cities", "\320\241\320\260\320\275\320\272\321\202-\320\237\320\265\321\202\320\265\321\200\320\261\321\203\321\200\320\263", nullptr));
        l5->setText(QApplication::translate("cities", "\320\222\320\276\320\273\320\263\320\276\320\263\321\200\320\260\320\264", nullptr));
        b5->setText(QApplication::translate("cities", "5", nullptr));
        l6->setText(QApplication::translate("cities", "\320\241\320\276\321\207\320\270", nullptr));
        b6->setText(QApplication::translate("cities", "6", nullptr));
        l4->setText(QApplication::translate("cities", "\320\242\321\216\320\274\320\265\320\275\321\214", nullptr));
        b4->setText(QApplication::translate("cities", "4", nullptr));
        l3->setText(QApplication::translate("cities", "\320\237\320\265\321\200\320\274\321\214", nullptr));
        b3->setText(QApplication::translate("cities", "3", nullptr));
        l2->setText(QApplication::translate("cities", "\320\234\320\276\321\201\320\272\320\262\320\260", nullptr));
        b2->setText(QApplication::translate("cities", "2", nullptr));
        bChangeSize->setText(QApplication::translate("cities", "\320\230\320\267\320\274\320\265\320\275\320\270\321\202\321\214 \321\200\320\260\320\267\320\274\320\265\321\200 \320\264\320\276\321\200\320\276\320\263\320\270", nullptr));
        bSelectCities->setText(QApplication::translate("cities", "\320\227\320\260\320\264\320\260\321\202\321\214 \320\263\320\276\321\200\320\276\320\264\320\260", nullptr));
        bCreateARoute->setText(QApplication::translate("cities", "\320\241\320\276\320\267\320\264\320\260\321\202\321\214 \320\274\320\260\321\200\321\210\321\200\321\203\321\202", nullptr));
        tablo_1->setText(QString());
        bvvod->setText(QApplication::translate("cities", "\320\222\320\262\320\276\320\264", nullptr));
        tablo_vivod->setText(QString());
        tablo_2->setText(QString());
        tablo_3->setText(QString());
        b11->setText(QApplication::translate("cities", "11", nullptr));
        b10->setText(QApplication::translate("cities", "10", nullptr));
        b9->setText(QApplication::translate("cities", "9", nullptr));
        b8->setText(QApplication::translate("cities", "8", nullptr));
        b12->setText(QApplication::translate("cities", "12", nullptr));
        b7->setText(QApplication::translate("cities", "7", nullptr));
        b13->setText(QApplication::translate("cities", "13", nullptr));
        b15->setText(QApplication::translate("cities", "15", nullptr));
        b14->setText(QApplication::translate("cities", "14", nullptr));
        bclear->setText(QApplication::translate("cities", "\320\236\321\207\320\270\321\201\321\202\320\270\321\202\321\214", nullptr));
        l11->setText(QApplication::translate("cities", "\320\234\321\203\321\200\320\274\320\260\320\275\321\201\320\272", nullptr));
        l12->setText(QApplication::translate("cities", "\320\222\320\276\321\200\320\272\321\203\321\202\320\260", nullptr));
        l14->setText(QApplication::translate("cities", "\320\235\320\276\320\262. \320\243\321\200\320\265\320\275\320\263\320\276\320\271", nullptr));
        l15->setText(QApplication::translate("cities", "\320\241\321\203\321\200\320\263\321\203\321\202", nullptr));
        l7->setText(QApplication::translate("cities", "\320\220\321\201\321\202\321\200\320\260\321\205\320\260\320\275\321\214", nullptr));
        l9->setText(QApplication::translate("cities", "\320\222\320\276\321\200\320\276\320\275\320\265\320\266", nullptr));
        l8->setText(QApplication::translate("cities", "\320\232\320\260\320\267\320\260\320\275\321\214", nullptr));
        l13->setText(QApplication::translate("cities", "\320\236\320\274\321\201\320\272", nullptr));
        l10->setText(QApplication::translate("cities", "\320\220\321\200\321\205\320\260\320\275\320\263\320\265\320\273\321\214\321\201\320\272", nullptr));
        blanguage->setText(QApplication::translate("cities", "ENG", nullptr));
    } // retranslateUi

};

namespace Ui {
    class cities: public Ui_cities {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_CITIES_H
