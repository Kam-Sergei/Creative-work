/****************************************************************************
** Meta object code from reading C++ file 'cities.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.12.10)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../../Cities/cities.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'cities.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.12.10. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_cities_t {
    QByteArrayData data[17];
    char stringdata0[197];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_cities_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_cities_t qt_meta_stringdata_cities = {
    {
QT_MOC_LITERAL(0, 0, 6), // "cities"
QT_MOC_LITERAL(1, 7, 24), // "on_bSelectCities_clicked"
QT_MOC_LITERAL(2, 32, 0), // ""
QT_MOC_LITERAL(3, 33, 16), // "on_bvvod_clicked"
QT_MOC_LITERAL(4, 50, 8), // "function"
QT_MOC_LITERAL(5, 59, 1), // "e"
QT_MOC_LITERAL(6, 61, 9), // "reduction"
QT_MOC_LITERAL(7, 71, 24), // "on_bCreateARoute_clicked"
QT_MOC_LITERAL(8, 96, 17), // "on_bclear_clicked"
QT_MOC_LITERAL(9, 114, 12), // "creatingitem"
QT_MOC_LITERAL(10, 127, 1), // "i"
QT_MOC_LITERAL(11, 129, 1), // "j"
QT_MOC_LITERAL(12, 131, 1), // "a"
QT_MOC_LITERAL(13, 133, 5), // "color"
QT_MOC_LITERAL(14, 139, 22), // "on_bChangeSize_clicked"
QT_MOC_LITERAL(15, 162, 20), // "on_blanguage_clicked"
QT_MOC_LITERAL(16, 183, 13) // "pushNumButton"

    },
    "cities\0on_bSelectCities_clicked\0\0"
    "on_bvvod_clicked\0function\0e\0reduction\0"
    "on_bCreateARoute_clicked\0on_bclear_clicked\0"
    "creatingitem\0i\0j\0a\0color\0"
    "on_bChangeSize_clicked\0on_blanguage_clicked\0"
    "pushNumButton"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_cities[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
      10,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags
       1,    0,   64,    2, 0x08 /* Private */,
       3,    0,   65,    2, 0x08 /* Private */,
       4,    1,   66,    2, 0x08 /* Private */,
       6,    0,   69,    2, 0x08 /* Private */,
       7,    0,   70,    2, 0x08 /* Private */,
       8,    0,   71,    2, 0x08 /* Private */,
       9,    4,   72,    2, 0x08 /* Private */,
      14,    0,   81,    2, 0x08 /* Private */,
      15,    0,   82,    2, 0x08 /* Private */,
      16,    0,   83,    2, 0x0a /* Public */,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,    5,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int, QMetaType::Int, QMetaType::Int, QMetaType::Bool,   10,   11,   12,   13,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

void cities::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<cities *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->on_bSelectCities_clicked(); break;
        case 1: _t->on_bvvod_clicked(); break;
        case 2: _t->function((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 3: _t->reduction(); break;
        case 4: _t->on_bCreateARoute_clicked(); break;
        case 5: _t->on_bclear_clicked(); break;
        case 6: _t->creatingitem((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2])),(*reinterpret_cast< int(*)>(_a[3])),(*reinterpret_cast< bool(*)>(_a[4]))); break;
        case 7: _t->on_bChangeSize_clicked(); break;
        case 8: _t->on_blanguage_clicked(); break;
        case 9: _t->pushNumButton(); break;
        default: ;
        }
    }
}

QT_INIT_METAOBJECT const QMetaObject cities::staticMetaObject = { {
    &QMainWindow::staticMetaObject,
    qt_meta_stringdata_cities.data,
    qt_meta_data_cities,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *cities::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *cities::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_cities.stringdata0))
        return static_cast<void*>(this);
    return QMainWindow::qt_metacast(_clname);
}

int cities::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 10)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 10;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 10)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 10;
    }
    return _id;
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
